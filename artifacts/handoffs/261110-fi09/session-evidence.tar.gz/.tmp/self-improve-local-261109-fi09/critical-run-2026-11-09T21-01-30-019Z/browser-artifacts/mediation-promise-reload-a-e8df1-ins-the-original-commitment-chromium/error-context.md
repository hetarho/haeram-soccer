# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mediation.spec.ts >> promise-reload-and-deadline with loan retains the original commitment
- Location: tests/e2e/mediation.spec.ts:259:3

# Error details

```
Test timeout of 90000ms exceeded.
```

```
Error: expect(locator).toBeVisible() failed

Locator: getByTestId('club-hub')
Expected: visible
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByTestId('club-hub') with timeout 15000ms
  - waiting for getByTestId('club-hub')
  - Test timeout of 90000ms exceeded.

```

```yaml
- complementary:
  - heading "HAERAM" [level=1]
  - text: FOOTBALL MANAGER A CLUB. A CENTURY.
  - navigation "게임 메뉴":
    - button "클럽하우스" [disabled]
    - button "리그" [disabled]
    - button "컵" [disabled]
    - button "팀" [disabled]
    - button "이적시장" [disabled]
    - button "기록" [disabled]
  - text: 기록은 이 브라우저에 저장됩니다. 파일로 당신의 역사를 보관하세요.
  - button "기록 내보내기 ↓" [disabled]
  - text: 기록 가져오기
  - button "기록 가져오기" [disabled]
- main:
  - text: Haeram Football 베타 버전 0.8 · 정식 출시 전까지 게임이 바뀔 수 있어요 1930 · A NEW OWNER
  - button "언어·테마"
  - status: 세계를 준비하고 있어요…
  - text: 기록 파일 가져오기
  - button "기록 파일 가져오기" [disabled]
```

# Test source

```ts
  1  | import { expect, type Page } from '@playwright/test';
  2  | import { operate, advanceDays, transferOffers } from '../../packages/engine/src/index';
  3  | import { careerWorld } from '../../packages/engine/src/career.testkit';
  4  | import type { World } from '../../packages/contracts/src/types';
  5  | import { ratio } from '../../packages/engine/src/primitives';
  6  | import { encode } from '../../apps/web/src/adapters/persistence';
  7  | import { startFlow } from './start';
  8  | 
  9  | /** A portable checkpoint built through actual bid and settlement commands, never DOM state edits. */
  10 | export function pendingAcquisitionCareer() {
  11 |   const w = careerWorld({ country: 'ENG', seed: 'responsibility-pending' });
  12 |   w.cash = w.income = '999999999999';
  13 |   const settings = structuredClone(w.settings!);
  14 |   settings.responsibilities.staff = 'direct';
  15 |   settings.responsibilities.sales = 'delegated';
  16 |   operate(w, { type: 'settings', settings });
  17 |   const offers = transferOffers(w);
  18 |   for (let candidate = 0; candidate < offers.length; candidate++) {
  19 |     const offer = offers[candidate];
  20 |     if (!offer.available || offer.freeAgent || BigInt(offer.fee) <= 0n) continue;
  21 |     operate(w, { type: 'bid', candidate, fee: ratio(offer.fee, 8n, 10n) });
  22 |   }
  23 |   for (let day = 0; day < 4; day++) advanceDays(w, 1, undefined, false);
  24 |   const counters = (w.bids || []).filter(
  25 |     (bid) => bid.direction === 'out' && bid.status === 'countered',
  26 |   );
  27 |   expect(counters.length).toBeGreaterThanOrEqual(2);
  28 |   for (const bid of counters.slice(2))
  29 |     operate(w, { type: 'respond-bid', id: bid.id, accept: false });
  30 |   expect(w.bids?.filter((bid) => bid.status === 'countered')).toHaveLength(2);
  31 |   return w;
  32 | }
  33 | export async function importResponsibilityCareer(page: Page, world: World) {
  34 |   await page.goto('/');
  35 |   await expect(startFlow(page)).toBeVisible();
  36 |   await page
  37 |     .locator('input[type=file]')
  38 |     .last()
  39 |     .setInputFiles({
  40 |       name: 'responsibilities.json',
  41 |       mimeType: 'application/json',
  42 |       buffer: Buffer.from(await encode(world, 1, 0)),
  43 |     });
  44 |   // A 35-round career on the released model: CI WebKit 40233059787 opened it in over 5 s.
> 45 |   await expect(page.getByTestId('club-hub')).toBeVisible({ timeout: 15000 });
     |                                              ^ Error: expect(locator).toBeVisible() failed
  46 | }
  47 | 
```