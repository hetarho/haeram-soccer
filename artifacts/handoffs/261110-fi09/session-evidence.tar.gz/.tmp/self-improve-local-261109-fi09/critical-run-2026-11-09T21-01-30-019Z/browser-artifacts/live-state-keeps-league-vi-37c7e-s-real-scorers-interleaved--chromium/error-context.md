# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: live-state.spec.ts >> keeps league views and nodes across silent progression and updates real scorers (interleaved)
- Location: tests/e2e/live-state.spec.ts:202:3

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Tearing down "context" exceeded the test timeout of 30000ms.
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary [ref=e4]:
    - generic [ref=e5]:
      - heading "HAERAM" [level=1] [ref=e6]
      - generic [ref=e7]: FOOTBALL MANAGER
      - generic [ref=e8]: A CLUB. A CENTURY.
    - navigation "게임 메뉴" [ref=e9]:
      - button "클럽하우스" [active] [ref=e10] [cursor=pointer]
      - button "리그" [ref=e11] [cursor=pointer]
      - button "컵" [ref=e12] [cursor=pointer]
      - button "팀" [ref=e13] [cursor=pointer]
      - button "이적시장" [ref=e14] [cursor=pointer]
      - button "기록" [ref=e15] [cursor=pointer]
  - main [ref=e16]:
    - generic [ref=e17]:
      - button "설정" [ref=e18] [cursor=pointer]
      - generic [ref=e28]:
        - generic [ref=e29]: Bristol Railway A5
        - generic [ref=e30]:
          - generic [aria-hidden] [ref=e31]: BETA
          - generic [ref=e32]: 베타 버전 0.8 · 정식 출시 전까지 게임이 바뀔 수 있어요
      - generic [ref=e33]: 1930.08.08
      - button "구단 자금 £79,514 11s 2d · 사업자금 £9,820,104 16s 3d · 자금 관리" [ref=e34] [cursor=pointer]:
        - generic [ref=e35]:
          - generic [ref=e36]: 구단 자금
          - generic [ref=e37]: £79,514
        - generic [ref=e38]: £9.82M
      - button "알림·뉴스 · 새 소식 8개" [ref=e40] [cursor=pointer]:
        - generic [aria-hidden] [ref=e42]: "8"
    - region "클럽 키우기" [ref=e46]:
      - region "이번 시즌" [ref=e47]:
        - generic [ref=e48]:
          - generic [ref=e49]: 잉글랜드 1부
          - generic [aria-hidden] [ref=e50]: 컵
          - generic [ref=e51]:
            - generic "우리 리그 38라운드 중 1라운드" [ref=e52]:
              - generic [ref=e53]: 라운드
              - generic [ref=e54]:
                - generic [ref=e55]: "1"
                - generic [ref=e56]: / 38
            - generic [ref=e57]:
              - generic [ref=e58]: 리그 순위
              - generic [ref=e59]:
                - generic [ref=e60]: "4"
                - generic [ref=e61]: /20위
            - generic [ref=e62]:
              - generic [ref=e63]: 승점 3
              - generic [ref=e64]: 1-0-0
          - generic [ref=e66]:
            - generic [ref=e67]: 컵대회
            - generic [ref=e68]: 1개
          - generic [ref=e69]:
            - generic [ref=e70]:
              - text: 리그 진행률
              - generic [ref=e71]: 0.0%
            - progressbar "리그 진행률" [ref=e72]
      - region "다음 경기" [ref=e73]:
        - generic [ref=e74]:
          - generic [ref=e75]:
            - heading "NEXT MATCH" [level=2] [ref=e76]
            - generic [ref=e77]: 리그
            - generic [ref=e78]: 홈
          - generic [ref=e79]:
            - heading [level=3] [ref=e80]:
              - text: vs
              - button "Leeds Railway B4 팀 정보" [ref=e81] [cursor=pointer]:
                - generic [ref=e89]: Leeds Railway B4
            - button "상세 리포트" [ref=e90] [cursor=pointer]
      - region "구단주 사무실" [ref=e91]:
        - img "1950–60년대 감독실 기본 · 매치데이 인쇄" [ref=e93]
        - generic [ref=e95]:
          - generic [ref=e96]: 구단주 사무실
          - generic [ref=e97]: 결재 대기 0건
          - button "들어가기" [ref=e98] [cursor=pointer]
      - navigation "구단 운영 분야" [ref=e99]:
        - button "1군 투자 관리" [ref=e100] [cursor=pointer]:
          - img "1950–60년대 4단계 훈련장 기본 · 매치데이 인쇄" [ref=e102]
          - generic:
            - generic: 1군
            - generic: 선수 지원 · 라커룸 문화 · 훈련장
        - button "유소년 투자 관리" [ref=e103] [cursor=pointer]:
          - img "1950–60년대 4단계 유소년 시설 기본 · 매치데이 인쇄" [ref=e105]
          - generic:
            - generic: 유소년
            - generic: 육성 투자 · 유입 방식 · 아카데미
        - button "코치진 투자 관리" [ref=e106] [cursor=pointer]:
          - img "1950–60년대 스태프 사무실 기본 · 매치데이 인쇄" [ref=e108]
          - generic:
            - generic: 코치진
            - generic: 재직 스태프의 상시 효과 · 급여 현황
        - button "경기장 투자 관리" [ref=e109] [cursor=pointer]:
          - img "경기장 외관" [ref=e111]
          - generic:
            - generic: 경기장
            - generic: 티켓 가격 · 관중석 증축 · 재건축
        - button "스카우팅 투자 관리" [ref=e112] [cursor=pointer]:
          - img "1950–60년대 감독실 기본 · 매치데이 인쇄" [ref=e114]
          - generic:
            - generic: 스카우팅
            - generic: 스카우팅 방식 · 해외 스카우트망
        - button "팬 · 마케팅 투자 관리" [ref=e115] [cursor=pointer]:
          - img "1950–60년대 구장 8단계 기본 · 매치데이 인쇄" [ref=e117]
          - generic:
            - generic: 팬 · 마케팅
            - generic: 지역 관계 · 지역 투자 · 해외 마케팅 · 투어
        - button "재정 · 사업 투자 관리" [ref=e118] [cursor=pointer]:
          - img "1950–60년대 감독실 기본 · 매치데이 인쇄" [ref=e120]
          - generic:
            - generic: 재정 · 사업
            - generic: 수익 모델 · 사업 투자 · 자금 투입 · 배당
        - button "구단 디자인 투자 관리" [ref=e121] [cursor=pointer]:
          - img "1950–60년대 구장 8단계 라커룸 기본 · 매치데이 인쇄" [ref=e123]
          - generic:
            - generic: 구단 디자인
            - generic: 디자인 의뢰 · 색상 · 문장 · 유니폼
    - region "시즌 진행" [ref=e124]:
      - generic [ref=e125]:
        - button "진행 방식 변경" [ref=e126] [cursor=pointer]:
          - generic [ref=e127]: "MODE:"
          - generic [ref=e128]: AUTO
        - button "결재함 · 대기 0건" [ref=e129] [cursor=pointer]:
          - text: 결재함
          - generic [aria-hidden]: "0"
        - button "결재 설정" [ref=e130] [cursor=pointer]
      - progressbar "시즌 경과 일수" [ref=e131]
      - group "자동 진행 속도" [ref=e132]:
        - button "자동 진행 시작" [ref=e133] [cursor=pointer]
        - combobox "자동 진행 배속" [ref=e135] [cursor=pointer]:
          - generic [ref=e136]: 2×
  - generic [ref=e139]: 저장 완료 · r9 · 물가 관측
```