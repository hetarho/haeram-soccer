import { closeSync, copyFileSync, existsSync, mkdirSync, openSync, readFileSync, writeFileSync } from 'node:fs';
import { execFileSync, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const helpers = path.dirname(fileURLToPath(import.meta.url));
const root = process.cwd();
const git = (...args) => execFileSync('git', args, { encoding: 'utf8' }).trim();
const source = () => ({ commit: git('rev-parse', 'HEAD'), tree: git('rev-parse', 'HEAD^{tree}'), dirty: git('status', '--porcelain') !== '' });
const hash = (file) => createHash('sha256').update(readFileSync(file)).digest('hex');
const shellQuote = (value) => "'" + value.replaceAll("'", "'\\''") + "'";
const taskIds = ['T754', 'T756', 'T760', 'T766', 'T767'];
const common = path.resolve(root, git('rev-parse', '--git-common-dir'));
const runtime = JSON.parse(readFileSync(path.join(common, 'haeram/v1/state.json'), 'utf8'));
const attempt = runtime.attempts[process.argv[2]];
if (!attempt || attempt.group !== 'fi09' || attempt.workspace !== root || JSON.stringify(attempt.tasks) !== JSON.stringify(taskIds) || attempt.status !== 'doing') throw new Error('LANE_ASSIGNMENT_MISMATCH');
const before = source();
if (before.dirty) throw new Error('LANE_SOURCE_DIRTY');
const directory = path.join(helpers, `lane-run-${new Date().toISOString().replace(/[:.]/g, '-')}`);
mkdirSync(directory);
const packetPath = path.join(directory, 'invocation.json');
const unitFile = path.join(directory, 'unit-results.json');
if (existsSync(unitFile)) throw new Error('LANE_UNIT_OUTPUT_EXISTS');
const command = `pnpm install --frozen-lockfile --prefer-offline && node ${shellQuote(path.join(helpers, 'reuse-typecheck-cache.mjs'))} restore && pnpm run typecheck && pnpm run lint && pnpm run format:check && pnpm run validate:i18n && pnpm exec vitest run --project unit --changed "$HAERAM_DIFF_BASE" --passWithNoTests --maxWorkers 1 --no-file-parallelism --reporter=default --reporter=json --outputFile=${shellQuote(unitFile)} && pnpm run build`;
const cli = '/Users/ihaelam/.npm/_npx/26287f45a133efbe/node_modules/haeram-spec-creator/bin/haeram-spec-creator.mjs';
const args = [cli, 'vibe', 'check', '--tier', 'task', '--diff-base', attempt.startCommit, '--no-cache', '--timeout-ms', '3600000', '--json', '--', command];
const packet = { phase: 'running', directory, packetPath, root, unitFile, unitOutputInitiallyAbsent: true, attempt: attempt.id, tasks: taskIds, base: attempt.startCommit, sourceBefore: before, producerSha256: hash(fileURLToPath(import.meta.url)), node: process.versions.node, platform: process.platform, arch: process.arch, command, executable: 'node', args, started: new Date().toISOString(), guardFile: path.join(directory, 'guard.json') };
const save = () => { const text = JSON.stringify(packet, null, 2) + '\n'; writeFileSync(packetPath, text); writeFileSync(path.join(helpers, 'lane-invocation.json'), text); };
save();
const out = openSync(packet.guardFile, 'w');
const err = openSync(path.join(directory, 'guard.stderr'), 'w');
let result;
try { result = spawnSync('node', args, { cwd: root, env: { ...process.env, HAERAM_TASK: taskIds.at(-1), HAERAM_TASKS: taskIds.join(' ') }, stdio: ['ignore', out, err] }); }
finally { closeSync(out); closeSync(err); }
packet.finished = new Date().toISOString();
packet.exitCode = result.status ?? 1;
packet.sourceAfter = source();
packet.guardSha256 = hash(packet.guardFile);
try {
  const guard = JSON.parse(readFileSync(packet.guardFile, 'utf8'));
  copyFileSync(guard.log, path.join(directory, 'guard-run.log'));
  packet.logFile = path.join(directory, 'guard-run.log');
  packet.logSha256 = hash(packet.logFile);
  packet.unitSha256 = hash(packet.unitFile);
} catch (error) { packet.captureError = error.message; }
packet.phase = 'finished';
save();
console.log(JSON.stringify({ exitCode: packet.exitCode, packetPath, sourceBefore: before, sourceAfter: packet.sourceAfter }));
process.exit(packet.exitCode);
