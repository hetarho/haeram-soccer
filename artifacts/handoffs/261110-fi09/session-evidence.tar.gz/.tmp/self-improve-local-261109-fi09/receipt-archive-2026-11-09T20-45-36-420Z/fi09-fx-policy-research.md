F18 future-policy research — proposal only, no model/rate adoption

Research date: 2026-11-09 UTC (2026-11-10 KST). Source fixed at a16e6d819fe0c02e4c224019af1af41ccea50372. All repository evidence below was read with git show/git grep at that SHA. No production/spec/task/state/Git/runtime/settings changes, world generation, tests or benchmarks were performed. No rate observations were imported into the game. Official-source metadata was browsed; this is not a complete currency-series inventory or a production approval.

Current amount, unit and date provenance

- packages/contracts/src/types.ts:1123–1137 defines CareerDate as season year/day from August 1, and CareerEmployment with optional wage/currency, employment from/to, contractUntil and grownThrough. There is no salary valuation date or FX observation/version field. packages/contracts/src/schema.ts:791–795 validates wage and currency as optional; currency is a bounded string, not proof of an ISO unit. schema.ts:35 permits season years 1901–4000. Employment from.year must not be relabelled as the current wage's valuation date.
- packages/engine/src/coaching-market.ts:100–106 records an actual two-year employment. Before ownership its wage is quoted for the employer country and currency; after ownership code is undefined and both wage/currency use the owner's world money. Therefore employer country alone does not identify the stored wage unit. Explicit job.currency is essential, and legacy missing provenance cannot be reconstructed safely from job.from alone.
- packages/engine/src/economy.ts:33–37 converts open employment wages whose explicit currency equals the world currency being replaced, and changes that currency tag. This is further evidence that job.from can predate the current denomination. Completed jobs are excluded by the existing code. This research proposes no rewrite of that lifecycle.
- packages/engine/src/managerMarket.ts:248–259 reads the active other-club coaching employment and calls employmentWageInBuyerCurrency(job, employerCountry, w.year, w.currency). Missing wage excludes an employed candidate (251). The current T759 leaf, employment-money.ts:5–26, uses an explicit stored currency-period identity, and only applies catalog fixed denomination changes if the employer's current unit is the buyer unit. Otherwise the stored number retains the legacy behavior; it does not implement nominal FX. This unresolved cross-unit path is the parked F18, not a newly accepted correction.
- managerMarket.ts:280 independently quotes the new manager's salary with staffQuote(w, 120 + ability), in buyer money. Compensation at 293–296 is the existing 3/2 integer-truncated multiple of the existing coaching wage. A new-buyer market salary is not the old employer's annual contractual salary. Ordinary generated NPC managers already use buyer-country staffQuote when ownership exists (145–165); a nominal FX change must not re-convert those buyer-money quotes.
- staff.ts:280–287 and quotes.ts:16–41,54–59 use national price/football indices to create market prices. These indices and the national baseline levels are not a market exchange-rate time series. Dividing country football quotes to convert the stored annual employment wage would add a new valuation policy, not recover a missing unit conversion.
- managerMarket.ts:390–405 uses fee + compensation + internal release for cash affordability and the separate new-wage difference for future runway. ops-staff.ts:173–177 debits the delegated candidate cost; 399–416 recomputes the current candidate and debits the same hiring total plus outgoing-manager payoff for an owner hire. Any adopted correction must feed one canonical buyer-unit compensation into disclosure, affordability and the actual debit. It must not independently alter new salaries, 1.5 multiplier, payoff, fee, staff policy or NPC budgets.

Complete relevant existing decisions read

STAFF-17 (spec/ssot/STAFF.md:72 block): another-club manager costs 1.5 annual wages; costs/status disclosed. STAFF-28 (:166 block): former-player employed coach recruited as manager costs 1.5 current annual coaching wages, retaining identity/service and ending coaching only on appointment. STAFF-43 (:245 block): actual club/post/contract dates and ordinary coaching pay recorded. STAFF-49 (:267 block): ordinary staff-post market, one annual wage of holder compensation, distinct from manager recruitment.

ECON-1 (:5) exact integer minor-unit strings; ECON-2/3 (:6–7) observed/estimated/projected distinction is explicit for price catalogs; ECON-4/5/6 (:8–13) nominal contracts fixed until renewal/conversion, verified denomination factors, live conversion once with explicit rounding, completed ledger units retained. ECON-26 (:157 block) national football price-index market amounts. ECON-33 (:189 block) existing wage caps/runway policy. ECON-35 (:207 block) national quote levels calibrated to 1999, buyer-money foreign-player prices, and explicit non-following of interwar/war exchange rates before 1949. Extending real nominal FX back through that excluded era needs owner policy clarification; existing CPI 2% projections do not authorize FX extrapolation.

Official primary-source evidence and constraints

1. ECB reference-rate landing page, observed on 2026-11-09 UTC, page date 9 November 2026:
https://www.ecb.europa.eu/stats/policy_and_exchange_rates/euro_reference_exchange_rates/html/index.en.html
All quoted currencies are foreign units per EUR base. Working-day publication is around 16:00 CET, with TARGET closing-day gaps. Informational reference rates are not executable transaction quotes. Historical CSV/XML downloads are linked. This report does not select a current rate or a spread.

2. ECB SDMX documentation:
https://www.ecb.europa.eu/stats/ecb_statistics/sdmx/html/index.en.html
It explicitly identifies historical daily reference data since 1999 and links SDMX 2.1 services. No pre-euro coverage can be inferred from this dataset.

3. Exact official ECB series metadata discovered, not invented:
https://data.ecb.europa.eu/data/datasets/EXR/EXR.A.GBP.EUR.SP00.A
https://data.ecb.europa.eu/data/datasets/EXR/EXR.D.GBP.EUR.SP00.A
Official indexed metadata reports annual frequency A, GBP numerator/currency, EUR denominator, spot SP00, average A; annual range 1999–2025 and last updated 28 January 2026 11:56 CET. Daily official indexed metadata starts 4 January 1999. Direct series fetches returned HTTP 503 in this investigation, so no fresh bulk series, checksum, complete gap inventory or API payload was verified. The official index page supplying the annual metadata is:
https://data.ecb.europa.eu/data/datasets/EXR?advFilterDataset%5BExchange+Rates++%28EXR%29%5D=Exchange+Rates++%28EXR%29&dataset%5B0%5D=Exchange+Rates++%28EXR%29&filterType=basic&filtersReset=false&layerType=DL&page=2&pageNum=33&pageSize=10&searchTerm=&selectedAdvTab=&showDatasetModal=false&sort=relevance
Do not treat a presently incomplete calendar year as a completed annual observation. Calendar-year averages and August–July season years are different periods. Inverting a published period average is mathematically different from averaging inverted daily observations; the game has chosen neither convention.

4. ECB methodology framework version dated 23 June 2026 (PDF page1):
https://www.ecb.europa.eu/stats/pdf/exchange/Frameworkfortheeuroforeignexchangereferencerates.en.pdf
It documents governance, input validation and methodology changes, with potential publication suspension. A production catalog would need a pinned raw snapshot, retrieval date, series identity, methodology version and observation status, rather than a live changing URL alone.

5. ECB euro launch/fixed conversion information:
https://www.ecb.europa.eu/euro/intro/html/index.en.html
Book money starts 1 January 1999; cash begins in 2002; fixed legacy national conversion factors are listed. These fixed conversion factors do not establish historical market exchange rates between national currencies before 1999. T759 remains the fixed-denomination baseline.

6. Bank of England spot-rate documentation, page last updated 11 March 2025, read 2026-11-09:
https://www.bankofengland.co.uk/statistics/details/further-details-about-spot-exchange-rates-data
Daily plus average/end-period monthly, quarterly and annual series exist. Spot settlement is conventionally two days later; these are statistical rather than specially authoritative executable rates. Legacy national currency series end on euro replacement. Current sourcing includes third-party providers; the page carries an LSEG redistribution restriction, so a specific series' reuse rights must be verified before vendoring. This does not establish a uniform first year for every relevant country. No all-country 1963 start or guessed legacy series keys are claimed here.

7. BoE primary archived publication, 1993Q1 statistical annex, printed pp121–146; PDF p10 contains sterling spot columns, p19 notes:
https://www.bankofengland.co.uk/-/media/boe/files/quarterly-bulletin/1993/statistical-annex-qb-1993-q1.pdf
The table includes historical DEM/sterling observations and separate effective indices/ECU/forward columns. These are distinct objects; a price index, effective exchange-rate index, ECU basket weight or forward premium cannot substitute for the nominal bilateral spot observation. OCR layout is insufficient to auto-adopt a complete annual legacy series without cell-level/visual validation. This is evidence of historical source material, not audited coverage for all seven legacy currencies.

8. BoE historical research dataset metadata, page updated 6 November 2026:
https://www.bankofengland.co.uk/statistics/research-datasets
The millennium dataset is version3.1, updated to2016; some UK macro variables reach medieval dates. This is not proof that every required bilateral FX pair has that coverage. Its workbook and per-series provenance would need a separate bounded audit before any historical alternative is adopted. No workbook was downloaded in this research.

Alternatives for an owner decision (none selected)

A. Preserve the current fixed-parity-only boundary and keep F18 parked.
Data: no nominal FX data. Existing T759 and save/job values remain unchanged. Unknown/foreign/future amounts retain current legacy behavior, whose unresolved unit limitation must remain documented; this is not claimed to correct F18. No affordability/debit/replay change and no save migration. Required decision if made a product policy rather than temporary parking: whether unsupported cross-unit recruitment should continue legacy numeric treatment, be unavailable, or present an explicit unpriced state. Changing availability/copy is itself separately authorized work.

B. Bounded nominal conversion for explicitly tagged GBP/EUR compensation only, within an audited ECB observation window.
Data: pin the chosen official series/frequency, raw bytes/hash, units, complete observation/gap/status inventory, retrieval/methodology/catalog version. Do not include country football indices or alter manager market salary quoting. Scope can exclude all pre1999 amounts and unsupported provenance. Needed owner decisions: conversion valuation date; daily vs completed-calendar-year vs explicitly defined season aggregation; weekend/closing-day rule; EUR-base inverse/cross convention; fixed denomination normalization vs nominal conversion order; minor-unit scaling and rounding stage; unsupported/unfinished-year/future4000 behavior. No automatic extrapolation is proposed. Impact: changes compensation, total cost, eligible delegated candidates and actual debit; new buyer salary and 1.5 multiplier remain separate. Preserve the original employment salary/unit, completed ledger facts and historical saves; choose an explicit rules/catalog-version approach so future read/hire/replay behavior is deterministic, with no silent rewriting of old transactions. Persisting new rate provenance in a save would require a separately reviewed schema/lifecycle decision.

C. Curated historical nominal conversion by audited currency-pair subranges, extending B only after evidence is complete.
Data: official BoE/national-authority series for GBP and the relevant pre-euro units (DEM/FRF/ESP/ITL/PTE/NLG/BEF), each with independently verified first/last dates, denomination identity, frequency, direction, source timing, rights, raw snapshot and transcribed-cell checks where needed. No uniform start year, annual series keys or synthetic legacy continuation are assumed. Pair-through-GBP conversions need common observation dates and an explicit aggregation/cross convention; a synthetic back-converted EUR series must not be labelled an observed national market rate. Early MARK/FRF-OLD/REIS and monetary-regime gaps remain unsupported until separately decided; ECON-35's pre1949 exclusion needs explicit owner treatment. Future years still have no observations. Affordability/debit/save consequences are the same as B but over a larger affected historical span; expect larger replay/outcome and data-maintenance scope. Any interpolation, backfill, frozen-last-rate or forecast would be a new economic policy needing its own approval and labels, not data cleanup.

Recommended next evidence/decision step only

Prepare a small nonproduction evidence manifest for explicit GBP/EUR compensation: wage-unit/date provenance cases, candidate scope, official raw series+metadata acquisition once the ECB service is available, checksum/gap inventory and denomination/minor-unit mapping. Then present the owner with the date/frequency, unknown/future behavior, inverse/aggregation/rounding and rules/save-version decisions above. Do not implement general FX, expand economic scope, reprice stored employment contracts, or publish rates in this run. The manifest is evidence gathering; it does not preselect B or any exchange-rate model. Existing NPC counterparty-budget questions remain separate and parked.
