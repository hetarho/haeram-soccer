import { closeSync, existsSync, mkdirSync, openSync, readFileSync, writeFileSync } from 'node:fs';
import { execFileSync, spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import path from 'node:path';
const root = process.cwd();
const deadline = '2026-11-09T22:06:00Z';
const closureReserveMs = 300000;
const git = (...args) => execFileSync('git', args, { encoding: 'utf8', timeout: Math.max(1, Math.min(60000, Date.parse(deadline) - Date.now())) }).trim();
const source = () => ({ commit: git('rev-parse', 'HEAD'), tree: git('rev-parse', 'HEAD^{tree}'), dirty: git('status', '--porcelain') !== '' });
const before = source();
if (root !== '/Users/ihaelam/project/haeram-soccer' || before.dirty || before.commit !== '61ba18e40cbe1ee5231e55b07d7563a25bbc965c') throw new Error('FROZEN_SOURCE_REQUIRED');
const critical = JSON.parse(readFileSync('.tmp/self-improve-local-261109-fi09/critical-invocation.json', 'utf8'));
if (!critical.finished || critical.running || critical.sourceAfter.commit !== before.commit || critical.sourceAfter.dirty) throw new Error('CRITICAL_DIAGNOSTICS_STILL_ACTIVE_OR_CHANGED');
const original = JSON.parse(readFileSync('.tmp/self-improve-local-261109-fi09/final-invocation.json', 'utf8'));
if (original.phase !== 'finished' || original.guard.exitCode === 0) throw new Error('ORIGINAL_FAILURE_REQUIRED');
const directory = path.resolve('.tmp/self-improve-local-261109-fi09', `failure-diagnostics-${new Date().toISOString().replace(/[:.]/g, '-')}`);
mkdirSync(directory);
const envelopePath = path.join(directory, 'invocation.json');
const pointerPath = path.resolve('.tmp/self-improve-local-261109-fi09/failure-diagnostics-invocation.json');
const envelope = { started: new Date().toISOString(), sourceBefore: before, directory, envelopePath, deadline, closureReserveMs, diagnosticOnly: true, fullBatchPassed: false, originalFullBatch: original.envelopePath, purpose: 'Obtain actual per-file error bodies/JSON for the five observed failures. Same source, all cases in each original file, one worker and original case timeouts. No claim about cache benefit, cause or overall pass.', phases: [] };
const save = () => { const bytes = JSON.stringify(envelope, null, 2) + '\n'; writeFileSync(envelopePath, bytes); writeFileSync(pointerPath, bytes); };
const invoke = async (command, args, prefix, env = process.env) => {
  const stdout = path.join(directory, `${prefix}.stdout`);
  const stderr = path.join(directory, `${prefix}.stderr`);
  const out = openSync(stdout, 'w');
  const err = openSync(stderr, 'w');
  const started = new Date().toISOString();
  let result;
  try { result = await new Promise((resolve) => {
    const child = spawn(command, args, { cwd: root, env, detached: true, stdio: ['ignore', out, err] });
    let closed = false, expired = false, cleanupFinished = false, code = null, signal = null, error;
    const watchdog = { stopAt: new Date(Date.parse(deadline) - closureReserveMs).toISOString(), childPid: child.pid, expired: false, ownedGroups: [] };
    const killGroup = (group, name) => { try { process.kill(-group, name); } catch (failure) { if (failure.code !== 'ESRCH') watchdog.cleanupError = failure.message; } };
    const finish = () => { if (closed && (!expired || cleanupFinished)) resolve({ status: expired ? 1 : code ?? 1, signal, error, watchdog }); };
    const timer = setTimeout(() => {
      expired = true;
      watchdog.expired = true;
      try {
        const rows = execFileSync('ps', ['-axo', 'pid=,ppid=,pgid='], { encoding: 'utf8', timeout: 5000 }).trim().split('\n').map((line) => line.trim().split(/\s+/).map(Number));
        const owned = new Set([child.pid]);
        for (let round = 0; round < rows.length; round++) { let added = false; for (const [pid, parent] of rows) if (owned.has(parent) && !owned.has(pid)) { owned.add(pid); added = true; } if (!added) break; }
        watchdog.ownedGroups = [...new Set(rows.filter(([pid]) => owned.has(pid)).map(([, , group]) => group))].filter((group) => group > 0 && rows.filter(([, , memberGroup]) => memberGroup === group).every(([pid]) => owned.has(pid)));
      } catch (failure) { watchdog.enumerationError = failure.message; }
      if (!watchdog.ownedGroups.includes(child.pid)) watchdog.ownedGroups.push(child.pid);
      // The installed CLI propagates SIGTERM to its detached command group. The
      // saved exclusive descendant groups also cover detached browser/server trees.
      killGroup(child.pid, 'SIGTERM');
      setTimeout(() => {
        for (const group of watchdog.ownedGroups) killGroup(group, 'SIGKILL');
        cleanupFinished = true;
        finish();
      }, 5000);
    }, Math.max(1, Date.parse(deadline) - closureReserveMs - Date.now()));
    child.on('error', (failure) => { error = failure.message; });
    child.on('close', (status, receivedSignal) => { closed = true; code = status; signal = receivedSignal; if (!expired) clearTimeout(timer); finish(); });
  }); } finally { closeSync(out); closeSync(err); }
  return { command, args, stdout, stderr, started, finished: new Date().toISOString(), exitCode: result.status, signal: result.signal, error: result.error, watchdog: result.watchdog };
};
save();
const env = { ...process.env, VITEST_MAX_WORKERS: '1', HAERAM_TASK: '', HAERAM_TASKS: '' };
const selections = [
  { name: 'club-staff', file: 'packages/engine/src/club-staff.test.ts', expectedCases: 12 },
  { name: 'staff-hiring', file: 'packages/engine/src/staff.hiring.test.ts', expectedCases: 17 },
  { name: 'grid-shape', file: 'packages/engine/src/grid/shape.test.ts', expectedCases: 35 },
];
for (const entry of selections) {
  if (Date.now() >= Date.parse(deadline) - closureReserveMs) { envelope.budgetExhausted = true; break; }
  const json = path.join(directory, `${entry.name}-results.json`);
  const args = [...(entry.file ? ['exec', 'vitest', 'run', '--project', 'unit', entry.file] : ['run', 'test:unit']), '--maxWorkers', '1', '--no-file-parallelism', '--reporter=default', '--reporter=json', `--outputFile=${json}`];
  envelope.running = { ...entry, args, started: new Date().toISOString() }; save();
  const result = { ...await invoke('pnpm', args, entry.name, env), ...entry, json, sourceAfter: source() };
  if (existsSync(json)) {
    const bytes = readFileSync(json);
    result.jsonSha256 = createHash('sha256').update(bytes).digest('hex');
    try {
      const report = JSON.parse(bytes);
      const cases = report.testResults.flatMap(suite => suite.assertionResults);
      result.actual = { success: report.success, total: report.numTotalTests, passed: report.numPassedTests, failed: report.numFailedTests, pending: report.numPendingTests, failedCases: cases.filter(test => test.status === 'failed').map(test => ({ name: test.fullName, errors: test.failureMessages })) };
      const completeCount = entry.expectedCases === null ? cases.length >= 2325 && report.numTotalTests === cases.length && report.numPassedTests === cases.length : cases.length === entry.expectedCases && report.numPassedTests === entry.expectedCases;
      result.completeFilePassed = result.exitCode === 0 && report.success === true && completeCount && report.numFailedTests === 0 && report.numPendingTests === 0 && cases.every(test => test.status === 'passed');
    } catch (error) { result.reportError = error.message; }
  }
  envelope.phases.push(result); delete envelope.running; save();
  if (result.sourceAfter.dirty || result.sourceAfter.commit !== before.commit || result.sourceAfter.tree !== before.tree) throw new Error('SOURCE_CHANGED');
  if (entry.name === 'grid-shape' && process.argv.includes('--full-unit-if-time') && envelope.phases.length === 3 && envelope.phases.every(phase => phase.completeFilePassed) && Date.parse(deadline) - closureReserveMs - Date.now() >= 1200000) {
    selections.push({ name: 'full-unit', file: null, expectedCases: null });
    envelope.fullUnitDecision = 'All three previously failed whole files actually passed serially on unchanged source; at least20m remains. Run the entire canonical unit project to address unresolved global unit coverage, preserving original limits and all cases. No batch-pass claim.';
    save();
  }
}
envelope.finished = new Date().toISOString(); envelope.sourceAfter = source(); save();
console.log(JSON.stringify({ envelopePath, diagnosticOnly: true, fullBatchPassed: false, phases: envelope.phases.map(({ name, exitCode, actual, completeFilePassed }) => ({ name, exitCode, actual, completeFilePassed })), budgetExhausted: envelope.budgetExhausted ?? false }));
process.exit(envelope.phases.length < 3 || envelope.phases.some(entry => !entry.completeFilePassed) ? 1 : 0);
