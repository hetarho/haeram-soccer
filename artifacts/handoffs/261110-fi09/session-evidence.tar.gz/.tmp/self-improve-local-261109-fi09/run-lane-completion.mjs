import { closeSync, copyFileSync, mkdirSync, openSync, readFileSync, writeFileSync } from 'node:fs';
import { execFileSync, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const helpers = path.dirname(fileURLToPath(import.meta.url));
const root = process.cwd();
const git = (...args) => execFileSync('git', args, { encoding: 'utf8' }).trim();
const hash = (file) => createHash('sha256').update(readFileSync(file)).digest('hex');
const quote = (value) => "'" + value.replaceAll("'", "'\\''") + "'";
const snapshot = () => ({ commit: git('rev-parse', 'HEAD'), tree: git('rev-parse', 'HEAD^{tree}'), dirty: git('status', '--porcelain') !== '' });
const prefix = JSON.parse(readFileSync(path.join(helpers, 'lane-invocation.json'), 'utf8'));
const original = JSON.parse(readFileSync(prefix.guardFile, 'utf8'));
const decisionPath = path.join(helpers, 'task-verification-completion-decision.json');
const decision = JSON.parse(readFileSync(decisionPath, 'utf8'));
const before = snapshot();
if (root !== prefix.root || before.dirty || before.commit !== prefix.sourceBefore.commit || before.tree !== prefix.sourceBefore.tree || prefix.sourceAfter.commit !== before.commit || prefix.sourceAfter.tree !== before.tree || prefix.sourceAfter.dirty || !original.timedOut || original.ok || original.cached !== false || hash(prefix.guardFile) !== prefix.guardSha256 || hash(prefix.logFile) !== prefix.logSha256 || decision.source.commit !== before.commit) throw new Error('LANE_COMPLETION_NOT_FROZEN_PREFIX');
const directory = path.join(helpers, `lane-completion-${new Date().toISOString().replace(/[:.]/g, '-')}`);
mkdirSync(directory);
const unitFile = path.join(directory, 'unit-results.json');
const command = `pnpm exec vitest run --project unit --changed "$HAERAM_DIFF_BASE" --passWithNoTests ${decision.unitFiles.map(quote).join(' ')} --maxWorkers 1 --no-file-parallelism --reporter=default --reporter=json --outputFile=${quote(unitFile)} && pnpm run build`;
const cli = '/Users/ihaelam/.npm/_npx/26287f45a133efbe/node_modules/haeram-spec-creator/bin/haeram-spec-creator.mjs';
const args = [cli, 'vibe', 'check', '--tier', 'task', '--diff-base', prefix.base, '--no-cache', '--timeout-ms', '1200000', '--json', '--', command];
const packetPath = path.join(directory, 'invocation.json');
const packet = { phase: 'running', root, directory, packetPath, prefixPacket: prefix.packetPath, prefixSha256: hash(prefix.packetPath), decisionPath, decisionSha256: hash(decisionPath), sourceBefore: before, base: prefix.base, tasks: prefix.tasks, unitFiles: decision.unitFiles, unitFile, producerSha256: hash(fileURLToPath(import.meta.url)), node: process.versions.node, platform: process.platform, arch: process.arch, command, executable: 'node', args, started: new Date().toISOString(), guardFile: path.join(directory, 'guard.json') };
const save = () => { const text = JSON.stringify(packet, null, 2) + '\n'; writeFileSync(packetPath, text); writeFileSync(path.join(helpers, 'lane-completion-invocation.json'), text); };
save();
const out = openSync(packet.guardFile, 'w'), err = openSync(path.join(directory, 'guard.stderr'), 'w');
let result;
try { result = spawnSync('node', args, { cwd: root, env: { ...process.env, HAERAM_TASK: prefix.tasks.at(-1), HAERAM_TASKS: prefix.tasks.join(' ') }, stdio: ['ignore', out, err] }); }
finally { closeSync(out); closeSync(err); }
packet.finished = new Date().toISOString();
packet.exitCode = result.status ?? 1;
packet.sourceAfter = snapshot();
packet.guardSha256 = hash(packet.guardFile);
try {
  const guard = JSON.parse(readFileSync(packet.guardFile, 'utf8'));
  packet.logFile = path.join(directory, 'guard-run.log');
  copyFileSync(guard.log, packet.logFile);
  packet.logSha256 = hash(packet.logFile);
  packet.unitSha256 = hash(unitFile);
} catch (error) { packet.captureError = error.message; }
packet.phase = 'finished';
save();
console.log(JSON.stringify({ exitCode: packet.exitCode, packetPath, sourceBefore: before, sourceAfter: packet.sourceAfter }));
process.exit(packet.exitCode);
