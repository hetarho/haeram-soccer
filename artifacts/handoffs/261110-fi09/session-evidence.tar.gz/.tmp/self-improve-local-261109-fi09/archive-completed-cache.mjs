import { cpSync, existsSync, lstatSync, mkdirSync, readFileSync, readdirSync, readlinkSync, rmSync, writeFileSync } from 'node:fs';
import { execFileSync, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import path from 'node:path';

const root = process.cwd();
const id = process.argv[2];
if (!/^[a-f0-9-]{36}$/.test(id ?? '')) throw new Error('ATTEMPT_ID');
const state = JSON.parse(readFileSync('.git/haeram/v1/state.json', 'utf8'));
const attempt = state.attempts[id];
if (!attempt || attempt.group !== 'fi09' || !['integrated', 'released'].includes(attempt.status) || attempt.cleanedAt || state.groups.fi09.operation) throw new Error('COMPLETED_ATTEMPT_REQUIRED');
const git = (dir, ...args) => execFileSync('git', ['-C', dir, ...args], { encoding: 'utf8' }).trim();
const treeDigest = (dir) => {
  const entries = [];
  const visit = (current, prefix = '') => {
    for (const name of readdirSync(current).sort()) {
      const file = path.join(current, name), relative = path.join(prefix, name), stat = lstatSync(file);
      if (stat.isDirectory()) visit(file, relative);
      else if (stat.isSymbolicLink()) entries.push([relative, 'link', readlinkSync(file)]);
      else if (stat.isFile()) entries.push([relative, stat.size, createHash('sha256').update(readFileSync(file)).digest('hex')]);
      else throw new Error('NONREGULAR_EVIDENCE');
    }
  };
  visit(dir);
  return createHash('sha256').update(JSON.stringify(entries)).digest('hex');
};
const base = '/Users/ihaelam/project/.haeram-worktrees/haeram-soccer-7b6c81df/fi09-';
for (const dir of [attempt.workspace, ...(attempt.candidates ?? [])]) {
  if (!existsSync(dir)) continue;
  if (!dir.startsWith(base) || path.resolve(dir) === path.resolve(root)) throw new Error('OWNED_WORKSPACE_REQUIRED');
  if (git(dir, 'status', '--porcelain') !== '') { console.log(JSON.stringify({ preservedDirty: dir })); continue; }
  const head = git(dir, 'rev-parse', 'HEAD');
  if (spawnSync('git', ['merge-base', '--is-ancestor', head, 'HEAD']).status !== 0) { console.log(JSON.stringify({ preservedUnmerged: dir, head })); continue; }
  const ignored = git(dir, 'status', '--porcelain', '--ignored').split('\n').filter(Boolean).map((line) => line.slice(3));
  if (ignored.some((entry) => !['.tmp/', 'node_modules/', 'apps/web/dist/'].includes(entry))) { console.log(JSON.stringify({ preservedUnknownIgnored: dir, ignored })); continue; }
  const archive = path.resolve('.tmp/self-improve-local-261109-fi09/evidence-archive', path.basename(dir));
  mkdirSync(archive, { recursive: true });
  const temporary = path.join(dir, '.tmp');
  let digest;
  if (existsSync(temporary)) {
    const destination = path.join(archive, 'tmp');
    digest = treeDigest(temporary);
    if (!existsSync(destination)) cpSync(temporary, destination, { recursive: true, preserveTimestamps: true });
    if (treeDigest(destination) !== digest) throw new Error('EVIDENCE_ARCHIVE_MISMATCH');
  }
  writeFileSync(path.join(archive, 'archive.json'), JSON.stringify({ attempt: id, workspace: dir, head, ignored, temporarySha256: digest, archivedAt: new Date().toISOString() }, null, 2) + '\n');
  for (const relative of ['node_modules', 'apps/web/dist', '.tmp']) {
    const target = path.join(dir, relative);
    if (existsSync(target)) rmSync(target, { recursive: true, force: true });
  }
  console.log(JSON.stringify({ preparedForCliCleanup: dir, archivedEvidence: archive }));
}
