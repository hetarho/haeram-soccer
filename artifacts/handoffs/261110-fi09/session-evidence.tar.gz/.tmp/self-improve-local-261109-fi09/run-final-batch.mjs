import { closeSync, copyFileSync, cpSync, existsSync, mkdirSync, openSync, readFileSync, writeFileSync } from 'node:fs';
import { execFileSync, spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import path from 'node:path';

const root = process.cwd();
const deadline = '2026-11-09T22:06:00Z';
const closureReserveMs = 300000;
if (Date.now() >= Date.parse(deadline) - closureReserveMs) throw new Error('FINAL_BUDGET_EXHAUSTED');
const git = (...args) => execFileSync('git', args, { encoding: 'utf8', timeout: Math.max(1, Math.min(60000, Date.parse(deadline) - Date.now())) }).trim();
const source = () => ({ commit: git('rev-parse', 'HEAD'), tree: git('rev-parse', 'HEAD^{tree}'), dirty: git('status', '--porcelain') !== '' });
const before = source();
if (before.dirty) throw new Error('FINAL_SOURCE_DIRTY');
const deferredPath = path.resolve('.tmp/self-improve-local-261109-fi09/deferred-integration-inventory.json');
const deferredSha256 = createHash('sha256').update(readFileSync(deferredPath)).digest('hex');
if (deferredSha256 !== 'dd70e3053ac73d57b628e00e3ea4814308be975cf454676bbd6b904cb683ae84') throw new Error('FINAL_DEFERRED_INVENTORY_CHANGED');
const deferred = JSON.parse(readFileSync(deferredPath, 'utf8'));
for (const entry of [...deferred.files.map((entry) => ({ file: entry.file, hash: entry.sourceSha256 })), { file: deferred.integrationRegistry.file, hash: deferred.integrationRegistry.sha256 }]) if (createHash('sha256').update(readFileSync(entry.file)).digest('hex') !== entry.hash) throw new Error('FINAL_DEFERRED_SOURCE_CHANGED');
const runtime = JSON.parse(readFileSync('.git/haeram/v1/state.json', 'utf8'));
const group = runtime.groups.fi09;
const attempts = Object.values(runtime.attempts).filter((entry) => entry.group === 'fi09');
const integrated = new Set(attempts.filter((entry) => entry.status === 'integrated').flatMap((entry) => entry.tasks));
if (group.operation || group.path !== root || group.push !== null || git('branch', '--show-current') !== group.branch || attempts.some((entry) => !['integrated', 'released'].includes(entry.status)) || !group.taskScope.every((task) => integrated.has(task)) || Array.from({ length: 21 }, (_, index) => `T${747 + index}`).some((task) => !group.taskScope.includes(task))) throw new Error('FINAL_APPROVED_SCOPE_NOT_INTEGRATED');
const id = new Date().toISOString().replace(/[:.]/g, '-');
const directory = path.resolve('.tmp/self-improve-local-261109-fi09', `final-run-${id}`);
mkdirSync(directory, { recursive: true });
const envelopePath = path.join(directory, 'invocation.json');
const pointerPath = path.resolve('.tmp/self-improve-local-261109-fi09/final-invocation.json');
const envelope = { schemaVersion: 1, cwd: root, deadline, closureReserveMs, sourceBefore: before, directory, envelopePath, deferredInventory: { path: deferredPath, sha256: deferredSha256 }, started: new Date().toISOString(), phase: 'install', resourceSettings: { VITEST_MAX_WORKERS: '2', HAERAM_TASK: '', HAERAM_TASKS: '' }, resourceRationale: 'Two isolated Vitest workers for the complete coordinator gate, with unchanged full selection and original case timeouts. The task-tier serial broad timeout remains recorded; this resource choice is not a pass or a timing guarantee. Playwright configuration stays unchanged.' };
const executionEnv = { ...process.env, ...envelope.resourceSettings };
envelope.clearedReporterOverrides = [];
for (const key of ['PLAYWRIGHT_JSON_OUTPUT_FILE', 'PLAYWRIGHT_JSON_OUTPUT_DIR', 'PLAYWRIGHT_JSON_OUTPUT_NAME']) {
  if (key in executionEnv) envelope.clearedReporterOverrides.push(key);
  delete executionEnv[key];
}
const save = () => { const data = JSON.stringify(envelope, null, 2) + '\n'; writeFileSync(envelopePath, data); writeFileSync(pointerPath, data); };
const invoke = async (command, args, prefix, env = process.env) => {
  const stdout = path.join(directory, `${prefix}.stdout`);
  const stderr = path.join(directory, `${prefix}.stderr`);
  const out = openSync(stdout, 'w');
  const err = openSync(stderr, 'w');
  const started = new Date().toISOString();
  let result;
  try { result = await new Promise((resolve) => {
    const child = spawn(command, args, { cwd: root, env, detached: true, stdio: ['ignore', out, err] });
    let closed = false, expired = false, cleanupFinished = false, code = null, signal = null, error;
    const watchdog = { stopAt: new Date(Date.parse(deadline) - closureReserveMs).toISOString(), childPid: child.pid, expired: false, ownedGroups: [] };
    const killGroup = (group, name) => { try { process.kill(-group, name); } catch (failure) { if (failure.code !== 'ESRCH') watchdog.cleanupError = failure.message; } };
    const finish = () => { if (closed && (!expired || cleanupFinished)) resolve({ status: expired ? 1 : code ?? 1, signal, error, watchdog }); };
    const timer = setTimeout(() => {
      expired = true;
      watchdog.expired = true;
      try {
        const rows = execFileSync('ps', ['-axo', 'pid=,ppid=,pgid='], { encoding: 'utf8', timeout: 5000 }).trim().split('\n').map((line) => line.trim().split(/\s+/).map(Number));
        const owned = new Set([child.pid]);
        for (let round = 0; round < rows.length; round++) { let added = false; for (const [pid, parent] of rows) if (owned.has(parent) && !owned.has(pid)) { owned.add(pid); added = true; } if (!added) break; }
        watchdog.ownedGroups = [...new Set(rows.filter(([pid]) => owned.has(pid)).map(([, , group]) => group))].filter((group) => group > 0 && rows.filter(([, , memberGroup]) => memberGroup === group).every(([pid]) => owned.has(pid)));
      } catch (failure) { watchdog.enumerationError = failure.message; }
      if (!watchdog.ownedGroups.includes(child.pid)) watchdog.ownedGroups.push(child.pid);
      // The installed CLI propagates SIGTERM to its detached command group. The
      // saved exclusive descendant groups also cover detached browser/server trees.
      killGroup(child.pid, 'SIGTERM');
      setTimeout(() => {
        for (const group of watchdog.ownedGroups) killGroup(group, 'SIGKILL');
        cleanupFinished = true;
        finish();
      }, 5000);
    }, Math.max(1, Date.parse(deadline) - closureReserveMs - Date.now()));
    child.on('error', (failure) => { error = failure.message; });
    child.on('close', (status, receivedSignal) => { closed = true; code = status; signal = receivedSignal; if (!expired) clearTimeout(timer); finish(); });
  }); } finally { closeSync(out); closeSync(err); }
  return { command, args, stdout, stderr, started, finished: new Date().toISOString(), exitCode: result.status, signal: result.signal, error: result.error, watchdog: result.watchdog };
};
save();
envelope.install = await invoke('pnpm', ['install', '--frozen-lockfile', '--prefer-offline'], 'install');
envelope.sourceAfterInstall = source();
if (envelope.install.exitCode !== 0 || envelope.sourceAfterInstall.dirty || envelope.sourceAfterInstall.commit !== before.commit || envelope.sourceAfterInstall.tree !== before.tree) {
  envelope.phase = envelope.install.watchdog.expired ? 'failed-budget' : 'failed-install';
  envelope.finished = new Date().toISOString();
  save();
  console.log(JSON.stringify({ ok: false, envelopePath, phase: envelope.phase }));
  process.exit(1);
}
envelope.phase = 'collection';
save();
const collectionFile = path.join(directory, 'collection.json');
envelope.collection = await invoke('pnpm', ['exec', 'playwright', 'test', '--project=chromium', '--list', '--reporter=json', '--forbid-only'], 'collection', { ...executionEnv, PREVIEW_BUILD: '1', PLAYWRIGHT_JSON_OUTPUT_FILE: collectionFile });
envelope.collection.json = collectionFile;
envelope.sourceAfterCollection = source();
let collected;
try { collected = JSON.parse(readFileSync(collectionFile, 'utf8')); }
catch (error) { envelope.collection.error = error.message; }
const collectedIdentities = [];
let collectionScopeValid = collected?.config?.forbidOnly === true && collected?.config?.projects?.find((entry) => entry.name === 'chromium')?.repeatEach === 1;
const collectIdentities = (suites) => { for (const suite of suites ?? []) { for (const spec of suite.specs ?? []) { const test = spec.tests?.[0]; if (typeof spec.id !== 'string' || spec.tests?.length !== 1 || test?.projectName !== 'chromium' || test?.expectedStatus !== 'passed') collectionScopeValid = false; collectedIdentities.push(JSON.stringify([spec.id, test?.projectName])); } collectIdentities(suite.suites); } };
collectIdentities(collected?.suites);
envelope.collection.distinctCases = new Set(collectedIdentities).size;
collectionScopeValid &&= collectedIdentities.length >= 348 && envelope.collection.distinctCases === collectedIdentities.length;
if (envelope.collection.exitCode !== 0 || !collected || (collected.errors ?? []).length !== 0 || !collectionScopeValid || envelope.sourceAfterCollection.dirty || envelope.sourceAfterCollection.commit !== before.commit || envelope.sourceAfterCollection.tree !== before.tree) {
  envelope.phase = envelope.collection.watchdog.expired ? 'failed-budget' : 'failed-collection';
  envelope.finished = new Date().toISOString();
  save();
  console.log(JSON.stringify({ ok: false, envelopePath, phase: envelope.phase }));
  process.exit(1);
}
envelope.collection.jsonSha256 = createHash('sha256').update(readFileSync(collectionFile)).digest('hex');
envelope.guardTimeoutMs = Math.floor(Math.min(10800000, Date.parse(deadline) - Date.now() - closureReserveMs));
if (envelope.guardTimeoutMs <= 0) {
  envelope.phase = 'failed-budget';
  envelope.finished = new Date().toISOString();
  save();
  console.log(JSON.stringify({ ok: false, envelopePath, phase: envelope.phase }));
  process.exit(1);
}
envelope.phase = 'guard';
envelope.guard = { command: 'node', args: ['/Users/ihaelam/.npm/_npx/26287f45a133efbe/node_modules/haeram-spec-creator/bin/haeram-spec-creator.mjs', 'vibe', 'check', '--tier', 'batch', '--diff-base', before.commit, '--no-cache', '--timeout-ms', String(envelope.guardTimeoutMs), '--json', '--', 'pnpm', 'run', 'verify:batch'], stdout: path.join(directory, 'guard.stdout'), stderr: path.join(directory, 'guard.stderr'), started: new Date().toISOString() };
save();
envelope.guard = await invoke(envelope.guard.command, envelope.guard.args, 'guard', executionEnv);
envelope.sourceAfter = source();
envelope.artifactsDirectory = path.join(directory, 'verification');
if (existsSync('.tmp/verification')) cpSync('.tmp/verification', envelope.artifactsDirectory, { recursive: true, preserveTimestamps: true });
const hash = (file) => createHash('sha256').update(readFileSync(file)).digest('hex');
envelope.guard.stdoutSha256 = hash(envelope.guard.stdout);
envelope.artifactHashes = {};
for (const file of ['latest.json', 'unit-results.json', 'integration-results.json', 'contract-results.json', 'e2e-results.json']) {
  const target = path.join(envelope.artifactsDirectory, file);
  if (existsSync(target)) envelope.artifactHashes[file] = hash(target);
}
try {
  const guard = JSON.parse(readFileSync(envelope.guard.stdout, 'utf8'));
  if (typeof guard.log === 'string' && existsSync(guard.log)) {
    envelope.rawLog = path.join(directory, 'guard-run.log');
    copyFileSync(guard.log, envelope.rawLog);
    envelope.rawLogSha256 = hash(envelope.rawLog);
  }
} catch {}
envelope.phase = 'finished';
envelope.finished = new Date().toISOString();
save();
console.log(JSON.stringify({ ok: envelope.guard.exitCode === 0, envelopePath, pointerPath, commit: before.commit, artifacts: envelope.artifactsDirectory }));
process.exit(envelope.guard.exitCode);
