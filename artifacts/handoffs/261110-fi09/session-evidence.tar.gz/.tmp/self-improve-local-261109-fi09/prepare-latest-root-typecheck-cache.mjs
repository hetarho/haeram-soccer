import { constants, copyFileSync, existsSync, mkdirSync, readFileSync, statSync, unlinkSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import os from 'node:os';
import path from 'node:path';
const root = '/Users/ihaelam/project/haeram-soccer';
const helpers = path.join(root, '.tmp/self-improve-local-261109-fi09');
const warm = '/Users/ihaelam/project/.haeram-worktrees/haeram-soccer-7b6c81df/fi09-integrate-427b340f';
const original = path.join(warm, '.tmp/tsc/tsbuildinfo');
const cache = path.join(root, '.tmp/tsc/tsbuildinfo');
const expected = 'ef6b67480f2b235e08bc9b777599f9918c74c635790a946a99a373ab11a43277';
const hash = file => createHash('sha256').update(readFileSync(file)).digest('hex');
const assert = (ok, reason) => { if (!ok) throw new Error(reason); };
const git = (cwd, ...args) => execFileSync('git', args, { cwd, encoding: 'utf8', timeout: 60000 }).trim();
assert(process.cwd() === root && process.argv[2] === '--confirmed-no-active-cache-writers', 'QUIESCENT_ROOT_ONLY');
const runtime = JSON.parse(readFileSync(path.join(root, '.git/haeram/v1/state.json'), 'utf8'));
assert(!runtime.groups.fi09.operation && runtime.attempts['8659b097-19a2-4e85-a8e0-f51d81e6b37e'].status === 'integrated', 'INTEGRATION_NOT_FINISHED');
assert(git(root, 'status', '--porcelain') === '' && git(warm, 'status', '--porcelain') === '', 'SOURCE_DIRTY');
assert(git(warm, 'rev-parse', 'HEAD') === 'c15c8d2c4b2889f8727afa96f6ef1b9129527ee4', 'WARM_SOURCE_MOVED');
const proof = JSON.parse(execFileSync(process.execPath, [path.join(helpers, 'assert-lane-checks.mjs')], { cwd: root, encoding: 'utf8', timeout: 60000 }));
assert(proof.ok && proof.sameSourceTaskPhaseEvidence && proof.sourceCommit === 'ee2b958f85c4c9ad7a8a3563a5b1745b2acf94d2' && proof.prefixPassedChecks.includes('typecheck'), 'ACTUAL_PREFIX_SOURCE_PROOF_REQUIRED');
const manifest = JSON.parse(readFileSync(path.join(helpers, 'typecheck-seed/manifest.json'), 'utf8'));
const environment = cwd => ({ host: os.hostname(), platform: process.platform, arch: process.arch, node: process.versions.node, commonGitDir: path.resolve(cwd, git(cwd, 'rev-parse', '--git-common-dir')), files: Object.fromEntries(['package.json', 'pnpm-lock.yaml', 'tsconfig.json', 'node_modules/typescript/lib/_tsc.js'].map(file => [file, hash(path.join(cwd, file))])) });
assert(JSON.stringify(environment(root)) === JSON.stringify(manifest.environment) && JSON.stringify(environment(warm)) === JSON.stringify(manifest.environment), 'ENVIRONMENT_MISMATCH');
assert(hash(original) === expected, 'RAW_CACHE_CHANGED');
const info = JSON.parse(readFileSync(original, 'utf8'));
assert(info.version === '5.9.3' && !info.errors && !info.checkPending && Array.isArray(info.fileNames) && info.fileNames.length > 0 && info.fileNames.every(file => !path.isAbsolute(file) && path.resolve(warm, '.tmp/tsc', file).startsWith(warm + path.sep)), 'UNFINISHED_OR_NONPORTABLE_CACHE');
const broad = JSON.parse(readFileSync(path.join(helpers, 'lane-invocation.json'), 'utf8'));
const modified = statSync(original).mtimeMs;
assert(modified >= Date.parse(broad.started) - 2000 && modified <= Date.parse(broad.finished) + 2000, 'PREFIX_CACHE_TIME_MISMATCH');
const directory = path.join(helpers, `latest-root-typecheck-preparation-${new Date().toISOString().replace(/[:.]/g, '-')}`);
mkdirSync(directory);
const backup = path.join(directory, 'previous-tsbuildinfo');
const previousHash = hash(cache);
const receipt = { started: new Date().toISOString(), source: warm, sourceCommit: proof.sourceCommit, candidateCommit: proof.candidateCommit, cacheHash: expected, originalMtime: modified, previousHash, backup, environment: environment(root), proof, preparationOnly: true, verificationPassed: false, decision: 'Explicit one-time preparation from genuine successful typecheck phase, despite later broad unit failure. Independent review and original broad failure retained; actual full unchanged typecheck is required. No cache bytes edited.' };
const save = () => writeFileSync(path.join(directory, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
copyFileSync(cache, backup, constants.COPYFILE_EXCL);
assert(hash(backup) === previousHash && hash(cache) === previousHash && hash(original) === expected, 'BACKUP_OR_CACHE_RACE');
save();
unlinkSync(cache);
try {
  copyFileSync(original, cache, constants.COPYFILE_EXCL);
  assert(hash(cache) === expected && hash(original) === expected, 'COPY_NOT_EXACT');
  receipt.prepared = true;
} catch (error) {
  receipt.error = error.message;
  if (existsSync(cache)) {
    if (hash(cache) === expected) unlinkSync(cache);
    else { receipt.recovery = 'Unknown concurrently-created target preserved; backup retained'; save(); throw error; }
  }
  copyFileSync(backup, cache, constants.COPYFILE_EXCL);
  assert(hash(cache) === previousHash, 'RECOVERY_MISMATCH');
  receipt.recovery = 'Original bytes restored';
  save();
  throw error;
}
receipt.finished = new Date().toISOString();
save();
console.log(JSON.stringify({ prepared: true, verificationPassed: false, receiptPath: path.join(directory, 'receipt.json'), cacheHash: expected, requiredNext: 'Actual unchanged full typecheck' }));
