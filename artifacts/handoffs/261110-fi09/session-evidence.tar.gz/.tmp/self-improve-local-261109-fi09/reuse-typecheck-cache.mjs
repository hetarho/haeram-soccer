import { constants, copyFileSync, existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const directory = path.dirname(fileURLToPath(import.meta.url));
const seed = path.join(directory, 'typecheck-seed');
const cwd = process.cwd();
const hash = (file) => createHash('sha256').update(readFileSync(file)).digest('hex');
const git = (root, ...args) => execFileSync('git', ['-C', root, ...args], { encoding: 'utf8' }).trim();
const common = (root) => path.resolve(root, git(root, 'rev-parse', '--git-common-dir'));
const assert = (condition, message) => { if (!condition) throw new Error(message); };
const environment = (root) => {
  assert(!/"(?:extends|references)"\s*:/.test(readFileSync(path.join(root, 'tsconfig.json'), 'utf8')), 'CACHE_FLAT_CONFIG_REQUIRED');
  return { host: os.hostname(), platform: process.platform, arch: process.arch, node: process.versions.node, commonGitDir: common(root), files: Object.fromEntries(['package.json', 'pnpm-lock.yaml', 'tsconfig.json', 'node_modules/typescript/lib/_tsc.js'].map((file) => [file, hash(path.join(root, file))])) };
};

if (process.argv[2] === 'capture') {
  const receiptPath = path.resolve(process.argv[3]);
  const receipt = JSON.parse(readFileSync(receiptPath, 'utf8'));
  assert(receipt.group === 'fi09' && receipt.status === 'integrated' && receipt.integrationVerification?.length > 0 && receipt.integrationVerification.every((entry) => entry.command.includes('pnpm run typecheck') && entry.command.includes('pnpm run lint') && entry.command.includes('pnpm run validate:i18n') && entry.command.includes('pnpm run format:check')), 'CACHE_REQUIRES_COMPLETED_NATIVE_INTEGRATION');
  const root = receipt.candidate;
  assert(common(root) === common(cwd), 'CACHE_OTHER_CLONE');
  assert(git(root, 'status', '--porcelain') === '', 'CACHE_SOURCE_DIRTY');
  assert(git(root, 'rev-parse', 'HEAD') === receipt.candidateCommit && receipt.candidateCommit === receipt.integratedCommit, 'CACHE_RECEIPT_SOURCE_MISMATCH');
  const original = path.join(root, '.tmp/tsc/tsbuildinfo');
  const modified = statSync(original).mtimeMs;
  assert(receipt.integrationVerification.some((entry) => !entry.cached && Number.isFinite(Date.parse(entry.startedAt)) && modified >= Date.parse(entry.startedAt) - 2000 && modified <= Date.parse(entry.finishedAt) + 2000), 'CACHE_CHECK_WINDOW_MISMATCH');
  const info = JSON.parse(readFileSync(original, 'utf8'));
  assert(info.version === '5.9.3' && Array.isArray(info.fileNames) && info.fileNames.length > 0 && info.fileNames.every((file) => !path.isAbsolute(file) && path.resolve(root, '.tmp/tsc', file).startsWith(root + path.sep)), 'CACHE_LAYOUT_NOT_PORTABLE');
  assert(!info.checkPending && !info.errors, 'CACHE_UNFINISHED');
  assert(!existsSync(path.join(seed, 'manifest.json')), 'CACHE_SEED_ALREADY_CAPTURED');
  mkdirSync(seed, { recursive: true });
  copyFileSync(original, path.join(seed, 'tsbuildinfo'));
  copyFileSync(receiptPath, path.join(seed, 'integration-receipt.json'));
  const manifest = { captured: new Date().toISOString(), source: root, commit: git(root, 'rev-parse', 'HEAD'), integratedCommit: receipt.integratedCommit, originalReceipt: receiptPath, receiptSha256: hash(receiptPath), cacheSha256: hash(original), environment: environment(root), policy: 'Preparation only. Every destination must still execute the unchanged typecheck command and require its actual exit0. Never replace an active or existing cache.' };
  assert(hash(path.join(seed, 'tsbuildinfo')) === manifest.cacheSha256, 'CACHE_CHANGED_DURING_CAPTURE');
  writeFileSync(path.join(seed, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
  console.log(JSON.stringify({ captured: true, manifest }));
} else if (process.argv[2] === 'restore') {
  const target = path.join(cwd, '.tmp/tsc/tsbuildinfo');
  if (existsSync(target)) {
    console.log(JSON.stringify({ restored: false, reason: 'existing-local-incremental-cache-kept', requiredNext: 'pnpm run typecheck' }));
  } else {
    const manifest = JSON.parse(readFileSync(path.join(seed, 'manifest.json'), 'utf8'));
    assert(hash(path.join(seed, 'tsbuildinfo')) === manifest.cacheSha256 && hash(path.join(seed, 'integration-receipt.json')) === manifest.receiptSha256, 'CACHE_PROVENANCE_MISMATCH');
    assert(JSON.stringify(environment(cwd)) === JSON.stringify(manifest.environment), 'CACHE_ENVIRONMENT_MISMATCH');
    mkdirSync(path.dirname(target), { recursive: true });
    try {
      copyFileSync(path.join(seed, 'tsbuildinfo'), target, constants.COPYFILE_EXCL);
      console.log(JSON.stringify({ restored: true, source: manifest.source, sourceCommit: manifest.commit, cacheSha256: hash(target), requiredNext: 'pnpm run typecheck', verificationPassed: false }));
    } catch (error) {
      if (error.code !== 'EEXIST') throw error;
      console.log(JSON.stringify({ restored: false, reason: 'concurrently-created-local-cache-kept', requiredNext: 'pnpm run typecheck' }));
    }
  }
} else throw new Error('CACHE_ACTION_REQUIRED');
