import { closeSync, existsSync, mkdirSync, openSync, readFileSync, writeFileSync } from 'node:fs';
import { execFileSync, spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import path from 'node:path';
const root = process.cwd();
const deadline = '2026-11-09T22:06:00Z';
const closureReserveMs = 300000;
const git = (...args) => execFileSync('git', args, { encoding: 'utf8', timeout: 60000 }).trim();
const source = () => ({ commit: git('rev-parse', 'HEAD'), tree: git('rev-parse', 'HEAD^{tree}'), dirty: git('status', '--porcelain') !== '' });
const before = source();
if (root !== '/Users/ihaelam/project/haeram-soccer' || before.dirty || before.commit !== '61ba18e40cbe1ee5231e55b07d7563a25bbc965c') throw new Error('CRITICAL_FROZEN_SOURCE_REQUIRED');
const directory = path.resolve('.tmp/self-improve-local-261109-fi09', `critical-run-${new Date().toISOString().replace(/[:.]/g, '-')}`);
mkdirSync(directory);
const envelopePath = path.join(directory, 'invocation.json');
const pointerPath = path.resolve('.tmp/self-improve-local-261109-fi09/critical-invocation.json');
const envelope = { started: new Date().toISOString(), sourceBefore: before, directory, envelopePath, deadline, closureReserveMs, diagnosticOnly: true, fullBatchPassed: false, originalFullBatch: path.resolve('.tmp/self-improve-local-261109-fi09/final-invocation.json'), phases: [], expectedIntegrationFiles: ['apps/web/src/adapters/newsJournal.test.ts', 'packages/engine/src/projection.test.ts', 'packages/engine/src/projection.plain.test.ts'], browserGrep: 'keeps league views and nodes across silent progression and updates real scorers|promise-reload-and-deadline with loan retains the original commitment', requiredFullCoverageStillUnfulfilled: true };
const save = () => { const bytes = JSON.stringify(envelope, null, 2) + '\n'; writeFileSync(envelopePath, bytes); writeFileSync(pointerPath, bytes); };
const env = { ...process.env, VITEST_MAX_WORKERS: '1', HAERAM_TASK: '', HAERAM_TASKS: '' };
for (const key of ['PLAYWRIGHT_JSON_OUTPUT_FILE', 'PLAYWRIGHT_JSON_OUTPUT_DIR', 'PLAYWRIGHT_JSON_OUTPUT_NAME']) delete env[key];
const invoke = async (command, args, prefix, env = process.env) => {
  const stdout = path.join(directory, `${prefix}.stdout`);
  const stderr = path.join(directory, `${prefix}.stderr`);
  const out = openSync(stdout, 'w');
  const err = openSync(stderr, 'w');
  const started = new Date().toISOString();
  let result;
  try { result = await new Promise((resolve) => {
    const child = spawn(command, args, { cwd: root, env, detached: true, stdio: ['ignore', out, err] });
    let closed = false, expired = false, cleanupFinished = false, code = null, signal = null, error;
    const watchdog = { stopAt: new Date(Date.parse(deadline) - closureReserveMs).toISOString(), childPid: child.pid, expired: false, ownedGroups: [] };
    const killGroup = (group, name) => { try { process.kill(-group, name); } catch (failure) { if (failure.code !== 'ESRCH') watchdog.cleanupError = failure.message; } };
    const finish = () => { if (closed && (!expired || cleanupFinished)) resolve({ status: expired ? 1 : code ?? 1, signal, error, watchdog }); };
    const timer = setTimeout(() => {
      expired = true;
      watchdog.expired = true;
      try {
        const rows = execFileSync('ps', ['-axo', 'pid=,ppid=,pgid='], { encoding: 'utf8', timeout: 5000 }).trim().split('\n').map((line) => line.trim().split(/\s+/).map(Number));
        const owned = new Set([child.pid]);
        for (let round = 0; round < rows.length; round++) { let added = false; for (const [pid, parent] of rows) if (owned.has(parent) && !owned.has(pid)) { owned.add(pid); added = true; } if (!added) break; }
        watchdog.ownedGroups = [...new Set(rows.filter(([pid]) => owned.has(pid)).map(([, , group]) => group))].filter((group) => group > 0 && rows.filter(([, , memberGroup]) => memberGroup === group).every(([pid]) => owned.has(pid)));
      } catch (failure) { watchdog.enumerationError = failure.message; }
      if (!watchdog.ownedGroups.includes(child.pid)) watchdog.ownedGroups.push(child.pid);
      // The installed CLI propagates SIGTERM to its detached command group. The
      // saved exclusive descendant groups also cover detached browser/server trees.
      killGroup(child.pid, 'SIGTERM');
      setTimeout(() => {
        for (const group of watchdog.ownedGroups) killGroup(group, 'SIGKILL');
        cleanupFinished = true;
        finish();
      }, 5000);
    }, Math.max(1, Date.parse(deadline) - closureReserveMs - Date.now()));
    child.on('error', (failure) => { error = failure.message; });
    child.on('close', (status, receivedSignal) => { closed = true; code = status; signal = receivedSignal; if (!expired) clearTimeout(timer); finish(); });
  }); } finally { closeSync(out); closeSync(err); }
  return { command, args, stdout, stderr, started, finished: new Date().toISOString(), exitCode: result.status, signal: result.signal, error: result.error, watchdog: result.watchdog };
};
save();
const phase = async (name, args, extra = {}) => {
  if (Date.now() >= Date.parse(deadline) - closureReserveMs) { envelope.budgetExhausted = true; save(); return false; }
  envelope.running = { name, args, started: new Date().toISOString() }; save();
  const result = await invoke('pnpm', args, name, { ...env, ...extra });
  const after = source();
  result.name = name;
  result.sourceAfter = after;
  envelope.phases.push(result); delete envelope.running; save();
  if (after.dirty || after.commit !== before.commit || after.tree !== before.tree) throw new Error('CRITICAL_SOURCE_CHANGED');
  return result.exitCode === 0;
};
await phase('integration', ['exec', 'vitest', 'run', '--project', 'integration', ...envelope.expectedIntegrationFiles, '--maxWorkers', '1', '--no-file-parallelism', '--reporter=default', '--reporter=json', `--outputFile=${path.join(directory, 'integration-results.json')}`]);
await phase('contract', ['run', 'test:contract', '--reporter=default', '--reporter=json', `--outputFile=${path.join(directory, 'contract-results.json')}`]);
for (const name of ['validate:catalogs', 'validate:presentation', 'validate:i18n']) await phase(name.replace(':', '-'), ['run', name]);
const built = await phase('build', ['run', 'build']);
if (built) {
  const args = ['run', 'test:e2e', '--project=chromium', 'tests/e2e/live-state.spec.ts', 'tests/e2e/mediation.spec.ts', '--grep', envelope.browserGrep, '--forbid-only'];
  const collection = await phase('browser-collection', [...args, '--list', '--reporter=json'], { PREVIEW_BUILD: '1', PLAYWRIGHT_JSON_OUTPUT_FILE: path.join(directory, 'browser-collection.json') });
  if (collection) {
    const report = JSON.parse(readFileSync(path.join(directory, 'browser-collection.json'), 'utf8'));
    const cases = [];
    const walk = suites => { for (const suite of suites ?? []) { for (const spec of suite.specs ?? []) cases.push(spec); walk(suite.suites); } };
    walk(report.suites);
    if (cases.length !== 3 || (report.errors ?? []).length || report.config?.forbidOnly !== true || cases.some(spec => spec.tests?.length !== 1 || spec.tests[0].projectName !== 'chromium' || spec.tests[0].expectedStatus !== 'passed')) throw new Error('CRITICAL_BROWSER_COLLECTION_NOT_EXACT_THREE');
    envelope.collectedCases = cases.map(spec => ({ id: spec.id, title: spec.title, project: spec.tests[0].projectName })); save();
    await phase('browser', args, { PREVIEW_BUILD: '1', PLAYWRIGHT_JSON_OUTPUT_FILE: path.join(directory, 'browser-results.json') });
  }
}
envelope.sourceAfter = source();
envelope.finished = new Date().toISOString();
envelope.artifactHashes = {};
for (const file of ['integration-results.json', 'contract-results.json', 'browser-collection.json', 'browser-results.json']) if (existsSync(path.join(directory, file))) envelope.artifactHashes[file] = createHash('sha256').update(readFileSync(path.join(directory, file))).digest('hex');
save();
console.log(JSON.stringify({ envelopePath, diagnosticOnly: true, fullBatchPassed: false, phases: envelope.phases.map(({ name, exitCode }) => ({ name, exitCode })), budgetExhausted: envelope.budgetExhausted ?? false }));
process.exit(envelope.phases.some(entry => entry.exitCode !== 0) || envelope.budgetExhausted ? 1 : 0);
