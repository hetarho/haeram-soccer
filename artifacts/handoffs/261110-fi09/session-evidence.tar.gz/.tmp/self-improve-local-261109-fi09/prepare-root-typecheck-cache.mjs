import { constants, copyFileSync, existsSync, mkdirSync, readFileSync, unlinkSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import os from 'node:os';
import path from 'node:path';
const root = '/Users/ihaelam/project/haeram-soccer';
const directory = path.join(root, '.tmp/self-improve-local-261109-fi09');
const cache = path.join(root, '.tmp/tsc/tsbuildinfo');
const seedDirectory = path.join(directory, 'typecheck-seed');
const seed = JSON.parse(readFileSync(path.join(seedDirectory, 'manifest.json'), 'utf8'));
const hash = file => createHash('sha256').update(readFileSync(file)).digest('hex');
const assert = (ok, reason) => { if (!ok) throw new Error(reason); };
assert(process.cwd() === root, 'ROOT_ONLY');
assert(process.argv[2] === '--confirmed-no-active-root-typecheck', 'OPERATOR_NO_WRITER_CONFIRMATION_REQUIRED');
const runtime = JSON.parse(readFileSync(path.join(root, '.git/haeram/v1/state.json'), 'utf8'));
assert(!runtime.groups.fi09.operation, 'ACTIVE_GROUP_OPERATION');
const environment = { host: os.hostname(), platform: process.platform, arch: process.arch, node: process.versions.node, commonGitDir: path.resolve(root, execFileSync('git', ['rev-parse', '--git-common-dir'], { encoding: 'utf8' }).trim()), files: Object.fromEntries(['package.json', 'pnpm-lock.yaml', 'tsconfig.json', 'node_modules/typescript/lib/_tsc.js'].map(file => [file, hash(path.join(root, file))])) };
assert(JSON.stringify(environment) === JSON.stringify(seed.environment), 'ENVIRONMENT_MISMATCH');
assert(hash(path.join(seedDirectory, 'tsbuildinfo')) === seed.cacheSha256 && hash(path.join(seedDirectory, 'integration-receipt.json')) === seed.receiptSha256, 'SEED_PROVENANCE_MISMATCH');
const id = new Date().toISOString().replace(/[:.]/g, '-');
const backupDirectory = path.join(directory, `root-typecheck-preparation-${id}`);
mkdirSync(backupDirectory);
const backup = path.join(backupDirectory, 'previous-tsbuildinfo');
const previousHash = hash(cache);
const receipt = { started: new Date().toISOString(), root, cache, backup, previousHash, seedHash: seed.cacheSha256, seedCommit: seed.commit, preparationOnly: true, verificationPassed: false, operatorConfirmedNoActiveWriter: true, authority: 'Explicit root decision, independently reviewed by final_gate_audit. Preserve the inactive old335 cache and prepare the immutable completed16-task incremental cache before actually executing unchanged full typecheck. Source and cache records are never edited; no prior pass is inherited.' };
const save = () => writeFileSync(path.join(backupDirectory, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
copyFileSync(cache, backup, constants.COPYFILE_EXCL);
assert(hash(backup) === previousHash && hash(cache) === previousHash, 'BACKUP_OR_CURRENT_CACHE_MISMATCH');
save();
unlinkSync(cache);
try {
  receipt.restoreStdout = execFileSync(process.execPath, [path.join(directory, 'reuse-typecheck-cache.mjs'), 'restore'], { cwd: root, encoding: 'utf8', timeout: 60000 });
  const result = JSON.parse(receipt.restoreStdout);
  assert(result.restored === true && hash(cache) === seed.cacheSha256, 'RESTORE_NOT_EXACT');
  receipt.prepared = true;
} catch (error) {
  receipt.error = error.message;
  if (existsSync(cache)) {
    if (hash(cache) === seed.cacheSha256) unlinkSync(cache);
    else { receipt.recovery = 'Unexpected concurrently-created target preserved; original backup retained, no blind overwrite'; save(); throw error; }
  }
  copyFileSync(backup, cache, constants.COPYFILE_EXCL);
  assert(hash(cache) === previousHash, 'RECOVERY_MISMATCH');
  receipt.recovery = 'Original bytes restored';
  save();
  throw error;
}
receipt.finished = new Date().toISOString();
save();
console.log(JSON.stringify({ ...receipt, receiptPath: path.join(backupDirectory, 'receipt.json'), requiredNext: 'Actual unchanged full pnpm run typecheck' }));
