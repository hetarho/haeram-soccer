import { readFileSync, statSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import path from 'node:path';

const root = process.cwd();
const invocationPath = path.resolve(process.argv[2] ?? '.tmp/self-improve-local-261109-fi09/final-invocation.json');
const read = (file) => JSON.parse(readFileSync(file, 'utf8'));
const git = (...args) => execFileSync('git', args, { encoding: 'utf8' }).trim();
const assert = (condition, code) => { if (!condition) throw new Error(code); };
const digest = (file) => createHash('sha256').update(readFileSync(file)).digest('hex');
const invocation = read(invocationPath);
assert(invocation.phase === 'finished' && invocation.cwd === root && invocation.install?.exitCode === 0 && invocation.guard?.exitCode === 0, 'FINAL_INVOCATION_FAILED');
assert(digest(invocation.envelopePath) === digest(invocationPath), 'FINAL_INVOCATION_POINTER_MISMATCH');
const receiptPath = invocation.guard.stdout;
const directory = invocation.artifactsDirectory;
const reportPath = path.join(directory, 'latest.json');
const guard = read(receiptPath);
const report = read(reportPath);
const commit = git('rev-parse', 'HEAD');
const tree = git('rev-parse', 'HEAD^{tree}');
assert(git('status', '--porcelain') === '', 'FINAL_SOURCE_DIRTY');
for (const snapshot of [invocation.sourceBefore, invocation.sourceAfterInstall, invocation.sourceAfterCollection, invocation.sourceAfter]) assert(snapshot?.commit === commit && snapshot?.tree === tree && snapshot?.dirty === false, 'FINAL_INVOCATION_SOURCE_MISMATCH');
assert(invocation.resourceSettings?.VITEST_MAX_WORKERS === '2' && invocation.resourceSettings?.HAERAM_TASK === '' && invocation.resourceSettings?.HAERAM_TASKS === '', 'FINAL_INVOCATION_RESOURCE_POLICY');
assert(invocation.deadline === '2026-11-09T22:06:00Z' && invocation.closureReserveMs === 300000 && Number.isSafeInteger(invocation.guardTimeoutMs) && invocation.guardTimeoutMs > 0 && invocation.guardTimeoutMs <= 10800000 && invocation.guardTimeoutMs <= Date.parse(invocation.deadline) - invocation.closureReserveMs - Date.parse(invocation.guard.started) + 2000 && Date.parse(invocation.guard.finished) <= Date.parse(invocation.deadline), 'FINAL_USER_TIME_BUDGET');
const command = ['/Users/ihaelam/.npm/_npx/26287f45a133efbe/node_modules/haeram-spec-creator/bin/haeram-spec-creator.mjs', 'vibe', 'check', '--tier', 'batch', '--diff-base', commit, '--no-cache', '--timeout-ms', String(invocation.guardTimeoutMs), '--json', '--', 'pnpm', 'run', 'verify:batch'];
assert(invocation.guard.command === 'node' && JSON.stringify(invocation.guard.args) === JSON.stringify(command), 'FINAL_INVOCATION_COMMAND_MISMATCH');
for (const phase of [invocation.install, invocation.collection, invocation.guard]) assert(phase.watchdog?.stopAt === '2026-11-09T22:01:00.000Z' && phase.watchdog.expired === false, 'FINAL_WALL_DEADLINE_EXCEEDED');
assert(digest(receiptPath) === invocation.guard.stdoutSha256, 'FINAL_GUARD_DIGEST_MISMATCH');
assert(guard.ok === true && guard.exitCode === 0 && guard.cached === false && !guard.timedOut && !guard.stale, 'FINAL_GUARD_FAILED');
assert(guard.scope?.TIER === 'batch', 'FINAL_GUARD_SCOPE');
assert(guard.commit === commit && guard.tree === tree, 'FINAL_GUARD_SOURCE_MISMATCH');
assert(typeof guard.log === 'string' && statSync(guard.log).size > 0, 'FINAL_GUARD_RAW_LOG_MISSING');
assert(report.passed === true && report.scope === 'batch: Chromium', 'FINAL_BATCH_FAILED');
assert(report.source?.commit === commit && report.source?.tree === tree && report.source?.dirty === false, 'FINAL_BATCH_SOURCE_MISMATCH');
const started = Date.parse(invocation.guard.started);
const finished = Date.parse(invocation.guard.finished);
assert(Number.isFinite(started) && finished > started && Date.parse(report.started) >= started - 2000 && Date.parse(report.finished) <= finished + 2000 && statSync(reportPath).mtimeMs >= started - 2000 && statSync(reportPath).mtimeMs <= finished + 2000, 'FINAL_EXECUTION_WINDOW_MISMATCH');
assert(digest(reportPath) === invocation.artifactHashes['latest.json'] && digest(invocation.rawLog) === invocation.rawLogSha256 && digest(invocation.rawLog) === digest(guard.log), 'FINAL_RAW_CAPTURE_MISMATCH');
const expected = ['typecheck', 'lint', 'format:check', 'test:unit', 'test:integration', 'test:contract', 'validate:catalogs', 'validate:presentation', 'validate:i18n', 'build', 'test:e2e'];
assert(Array.isArray(report.stages) && report.stages.length === expected.length, 'FINAL_STAGES_MISSING');
for (let i = 0; i < expected.length; i++) {
  const stage = report.stages[i];
  assert(stage.stage === expected[i] && stage.exitCode === 0, 'FINAL_STAGE_FAILED');
  assert(Date.parse(stage.started) >= Date.parse(report.started) - 2000 && Date.parse(stage.finished) <= Date.parse(report.finished) + 2000 && Date.parse(stage.finished) >= Date.parse(stage.started), 'FINAL_STAGE_WINDOW_MISMATCH');
  const args = stage.stage === 'test:e2e' ? 'pnpm run test:e2e --project=chromium' : stage.stage.startsWith('test:') ? `pnpm run ${stage.stage} --reporter=default --reporter=json --outputFile=.tmp/verification/${stage.stage.slice(5)}-results.json` : `pnpm run ${stage.stage}`;
  assert(stage.command === args, 'FINAL_STAGE_COMMAND_MISMATCH');
}
const freshArtifact = (file, stageName) => {
  const stage = report.stages.find((entry) => entry.stage === stageName);
  const changed = statSync(file).mtimeMs;
  assert(changed >= Date.parse(stage.started) - 2000 && changed <= Date.parse(stage.finished) + 2000, 'FINAL_RAW_ARTIFACT_STALE');
};
const results = {};
const declared = read(path.resolve('.tmp/self-improve-local-261109-fi09/declared-pending.json'));
assert(declared.sourceCommit === '335f718280aa2fa58e195353f208c666f6f5616e' && declared.pending.length === 4 && digest(declared.evidence) === declared.evidenceSha256, 'FINAL_DECLARED_PENDING_EVIDENCE');
for (const [file, hash] of Object.entries(declared.files)) {
  assert(digest(path.resolve(file)) === hash && createHash('sha256').update(execFileSync('git', ['show', `${declared.sourceCommit}:${file}`])).digest('hex') === hash, 'FINAL_DECLARED_PENDING_SOURCE_CHANGED');
}
for (const project of ['unit', 'integration', 'contract']) {
  const file = path.join(directory, `${project}-results.json`);
  const value = read(file);
  freshArtifact(file, `test:${project}`);
  assert(digest(file) === invocation.artifactHashes[`${project}-results.json`], 'FINAL_VITEST_CAPTURE_MISMATCH');
  const allowed = project === 'integration' ? declared.pending : [];
  const pending = value.testResults.flatMap((suite) => (suite.assertionResults ?? []).filter((test) => !['passed', 'failed'].includes(test.status)).map((test) => ({ file: path.relative(root, suite.name), name: test.fullName, status: test.status })));
  const normalized = (items) => items.map((item) => JSON.stringify(item)).sort();
  assert(JSON.stringify(normalized(pending)) === JSON.stringify(normalized(allowed)), 'FINAL_UNDECLARED_PENDING_TEST');
  assert(value.success === true && value.numFailedTests === 0 && value.numFailedTestSuites === 0 && value.numPendingTests === allowed.length && (value.numTodoTests ?? 0) === 0 && value.numPassedTests === value.numTotalTests - allowed.length, 'FINAL_VITEST_RESULTS_FAILED');
  const minimum = project === 'unit' ? declared.unitMinimum : project === 'contract' ? declared.contractMinimum : read(declared.evidence).numTotalTests;
  assert(value.numTotalTests >= minimum, 'FINAL_VITEST_SCOPE_REDUCED');
  results[project] = { total: value.numTotalTests, passed: value.numPassedTests, pending: value.numPendingTests, sha256: digest(file) };
}
const deferredPath = path.resolve('.tmp/self-improve-local-261109-fi09/deferred-integration-inventory.json');
assert(digest(deferredPath) === 'dd70e3053ac73d57b628e00e3ea4814308be975cf454676bbd6b904cb683ae84' && invocation.deferredInventory?.path === deferredPath && invocation.deferredInventory.sha256 === digest(deferredPath), 'FINAL_DEFERRED_INVENTORY_MISMATCH');
const deferred = read(deferredPath);
assert(deferred.project === 'integration' && deferred.requiredCaseCount === 12 && deferred.files.length === 3 && deferred.files.reduce((total, file) => total + file.cases.length, 0) === 12, 'FINAL_DEFERRED_SCOPE');
assert(digest(path.resolve(deferred.integrationRegistry.file)) === deferred.integrationRegistry.sha256, 'FINAL_INTEGRATION_REGISTRY_CHANGED');
const integration = read(path.join(directory, 'integration-results.json'));
for (const entry of deferred.files) {
  assert(digest(path.resolve(entry.file)) === entry.sourceSha256 && createHash('sha256').update(execFileSync('git', ['show', `${deferred.source.commit}:${entry.file}`])).digest('hex') === entry.sourceSha256, 'FINAL_DEFERRED_SOURCE_CHANGED');
  const suites = integration.testResults.filter((suite) => path.relative(root, suite.name) === entry.file);
  assert(suites.length === 1 && suites[0].assertionResults.length === entry.requiredCaseCount && entry.cases.length === entry.requiredCaseCount, 'FINAL_DEFERRED_FILE_SCOPE');
  for (const test of entry.cases) {
    const matches = suites[0].assertionResults.filter((result) => result.fullName === test.fullName);
    assert(matches.length === 1 && matches[0].status === 'passed', 'FINAL_DEFERRED_CASE_NOT_PASSED');
  }
}
const e2ePath = path.join(directory, 'e2e-results.json');
const e2e = read(e2ePath);
freshArtifact(e2ePath, 'test:e2e');
assert(e2e.stats?.expected > 0 && e2e.stats.unexpected === 0 && e2e.stats.flaky === 0 && e2e.stats.skipped === 0, 'FINAL_CHROMIUM_RESULTS_FAILED');
assert(digest(e2ePath) === invocation.artifactHashes['e2e-results.json'], 'FINAL_CHROMIUM_CAPTURE_MISMATCH');
const tests = [];
const collect = (suites) => { for (const suite of suites) { for (const spec of suite.specs ?? []) tests.push(...(spec.tests ?? [])); collect(suite.suites ?? []); } };
collect(e2e.suites ?? []);
assert(tests.length === e2e.stats.expected && tests.every((test) => test.projectName === 'chromium' && test.status === 'expected' && test.results.length === 1 && test.results[0].status === 'passed'), 'FINAL_CHROMIUM_SCOPE_OR_RETRY');
const collection = invocation.collection;
assert(collection?.command === 'pnpm' && collection.exitCode === 0 && JSON.stringify(collection.args) === JSON.stringify(['exec', 'playwright', 'test', '--project=chromium', '--list', '--reporter=json', '--forbid-only']), 'FINAL_COLLECTION_COMMAND');
assert(Date.parse(collection.started) >= Date.parse(invocation.install.finished) - 2000 && Date.parse(collection.finished) <= started + 2000, 'FINAL_COLLECTION_WINDOW');
assert(digest(collection.json) === collection.jsonSha256 && statSync(collection.json).mtimeMs >= Date.parse(collection.started) - 2000 && statSync(collection.json).mtimeMs <= Date.parse(collection.finished) + 2000, 'FINAL_COLLECTION_RAW');
const listed = read(collection.json);
assert((listed.errors ?? []).length === 0 && listed.config?.forbidOnly === true, 'FINAL_COLLECTION_ERRORS');
const project = listed.config.projects.find((entry) => entry.name === 'chromium');
assert(project?.repeatEach === 1 && e2e.config.projects.find((entry) => entry.name === 'chromium')?.repeatEach === 1, 'FINAL_COLLECTION_REPEAT');
const identities = (report) => {
  const values = [];
  const visit = (suites) => { for (const suite of suites ?? []) { for (const spec of suite.specs ?? []) { assert(spec.tests?.length === 1 && spec.tests[0].projectName === 'chromium' && spec.tests[0].expectedStatus === 'passed', 'FINAL_COLLECTION_CASE_SCOPE'); values.push(JSON.stringify([spec.id, spec.tests[0].projectName])); } visit(suite.suites); } };
  visit(report.suites);
  assert(values.length >= 348 && new Set(values).size === values.length, 'FINAL_COLLECTION_REDUCED_OR_DUPLICATE');
  return values.sort();
};
assert(JSON.stringify(identities(listed)) === JSON.stringify(identities(e2e)), 'FINAL_COLLECTION_RUN_MISMATCH');
console.log(JSON.stringify({ ok: true, reusedVerifiedBatch: true, commit, tree, invocation: { path: invocation.envelopePath, sha256: digest(invocation.envelopePath), started: invocation.guard.started, finished: invocation.guard.finished }, guard: { path: receiptPath, sha256: digest(receiptPath), log: invocation.rawLog }, report: { path: reportPath, sha256: digest(reportPath), elapsedMs: report.elapsedMs }, vitest: results, deferredIntegrationPassed: deferred.requiredCaseCount, declaredExistingPending: declared.pending, chromium: { ...e2e.stats, sha256: digest(e2ePath) } }));
