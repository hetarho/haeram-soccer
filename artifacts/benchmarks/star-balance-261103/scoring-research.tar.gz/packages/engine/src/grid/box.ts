/**
 * The box scene of open play on the candidate model (→MATCH-33, MATCH-34, T443;
 * spec/ssot/MATCH.md). With the ball wide in the final third or in a cut-back zone
 * (MATCH-14), the attack occupies the box's zones with runs timed to the delivery and the defence
 * protects the same zones goal-side. The zones are points in the attacking side's frame, named by
 * the ball's side of the goal: deliveries are played into them (T444). `BOX_CONFIG.shot` sets how
 * the bodies in front of goal block a shot and where its second ball falls (T445, `resolve.ts`).
 * Everything here reads the state and changes nothing: `coordination.ts` gives out the jobs,
 * `intentions.ts` keeps and ends them, `shape.ts` moves the players.
 */
import type { Attribute, Position, RoleId } from '../../../contracts/src/player';
import { lineOf } from '../player';
import { CELL_BASELINES } from './baselines';
import { byId, COORDINATION_CONFIG, gap } from './coordination';
import { attackFrame, BAND_EDGES, cellOf, clamp, laneOf, PITCH, toEngine } from './pitch';
import type { Point } from './pitch';
import { reachOnPath, type LaneReach, type PathReach } from './lanes';
import { BOX_ROLES, SHAPE_CONFIG } from './shape';
import { SPOTS } from './spots';
import { onPitch, other, skill, slotOf, type GridPlayer, type GridState } from './state';

/** The zones the attack occupies, in the order a tie between equal distances takes them. */
export const BOX_ZONES = ['nearPost', 'farPost', 'spot', 'edge'] as const;
export type BoxZone = (typeof BOX_ZONES)[number];
/** What a defender guards: one of the zones, or the middle of the goal between the posts' zones. */
export type BoxGuard = BoxZone | 'middle';
/** The ball's side of the goal in the attacking side's frame: −1 its left (low y), 1 its right. */
export type BallSide = -1 | 1;
/** How a delivery is played into its zone (T444, `BOX_CONFIG.delivery.kinds`). */
export type DeliveryKind = 'near' | 'far' | 'back' | 'square';
/** The carrier's action each kind is (→MATCH-16's mix decides which he plays): a cut-back is pulled back. */
export const DELIVERY_ACTION: Record<DeliveryKind, 'cross' | 'cutBack'> = {
  near: 'cross',
  far: 'cross',
  square: 'cross',
  back: 'cutBack',
};
/** A ball lofted into its zone (his head), against one played low to his feet. */
export const lofted = (kind: DeliveryKind) => kind === 'far';

/** Where a delivery is played (T444): the zone of a scene named for the ball's side, and how. */
export interface DeliveryAim {
  zone: BoxZone;
  kind: DeliveryKind;
  ball: BallSide;
}
/**
 * A delivery the carrier may play: its aim, the runner arriving there and his weight in the draw;
 * its path's reach as it stands (T446, `deliveryReach` kicked now): the reaching opponents' summed
 * weight, and whether one of them cuts it out cleanly.
 */
export interface Delivery extends DeliveryAim {
  runner: number;
  score: number;
  reach: number;
  cut: boolean;
}

/**
 * A box-scene job an intention carries (T443): the zone a runner attacks or a defender guards, and
 * the ball's side it was named for. Replaced, never changed in place, since traces keep it.
 */
export interface BoxJob {
  readonly zone: BoxGuard;
  readonly ball: BallSide;
}

/** Initial values for the candidate model; T437 calibrates them against the unchanged targets. */
export const BOX_CONFIG = {
  /** The scene is on with the ball in a wide lane from this many metres (the attack frame) up. */
  wideFrom: 70,
  /** Experimental central occupation; 0 keeps the released wide-delivery scene. */
  centralFrom: 0,
  /** Experimental nearest eligible arrivals, rather than fixed forward-first post assignment. */
  rotate: false,
  /** Half the goal's width (7.32 m): how far a post stands from the goal's middle. */
  post: 3.66,
  /**
   * The zones, in metres from the goal line (`out`) and across from the posts: the near post 3 m
   * inside the near post, the far post 1 m beyond the far post, the penalty spot and the edge of
   * the box (아크 정면) on the goal's middle. T447: the far post 8 m out, beyond the six-yard line,
   * where a lofted ball to it is met (3 m before, inside the goal area; calibration round 76, core
   * 600: goals 3.00 → 2.71 a match, goal-area shots 9.6 → 6.7%, 5.5 m 2.96, 6.5 m 2.91, 7.5 m
   * 2.74). The near post's depth moved nothing (4.5 m 2.94, 5.5 m 3.00) and stays.
   */
  zones: {
    nearPost: { out: 3.5, inside: 3 },
    farPost: { out: 8, beyond: 1 },
    spot: { out: 11 },
    edge: { out: 19 },
  },
  /** A runner waits this many metres short of his zone (toward halfway) until a delivery is decided. */
  load: 4,
  /** An attacker further than this many metres from a zone cannot arrive in time and is not sent. */
  reach: 30,
  /** Seconds a box-scene job holds at most; one still called for is given again at once. */
  seconds: 8,
  /** Roles that arrive in the box besides `SHAPE_CONFIG`'s box-run roles (→PLAYER-5). */
  roles: ['shadowStriker', 'attackingMidfielder'] as readonly RoleId[],
  defend: {
    /**
     * Metres from its goal the defending back line drops to: the deeper end with the ball on the
     * byline, the shallower with it `wideFrom` up, linear between.
     */
    line: [5.5, 11] as readonly [number, number],
    /** The share of its distance from the centre line a back-line player keeps as it narrows. */
    narrow: 0.6,
  },
  /**
   * The delivery into the zones (T444, →MATCH-33). `kinds` by zone: `near` driven low to the near
   * post, `far` lofted to the far post, `back` a cut-back to the spot or the edge, `square` low
   * across the goal area to the far-post runner (from the goal-area band only, the cut-back zones
   * included). A runner's weight in the draw is `free` × whether he arrives free (no opponent
   * within `freeRadius` m of his zone) + `suit` × how the ball suits him (`lofted` or `low`, his
   * attributes' 0–1 shares) + his zone's xT, less `risk` × his path's reach (T446, `deliveryReach`:
   * the reaching opponents' summed lane weights). A lofted ball is reachable only within `loft.foot`
   * m off the crosser's foot and its last `loft.drop` m before its zone.
   */
  delivery: {
    kinds: {
      nearPost: ['near'],
      farPost: ['far', 'square'],
      spot: ['back'],
      edge: ['back'],
    } as Record<BoxZone, readonly DeliveryKind[]>,
    free: 1,
    freeRadius: 2,
    suit: 0.8,
    lofted: { heading: 0.6, strength: 0.4 } as Partial<Record<Attribute, number>>,
    low: { finishing: 0.7, composure: 0.3 } as Partial<Record<Attribute, number>>,
    loft: { foot: 3, drop: 2 },
    /**
     * T446: 3. No value moved goals beyond the noise (calibration round 75, core 600: 2.91 at 0,
     * 2.94 at 1, 2.93 at 3, 2.96 at 8 a match); 3 sends the fewest balls along a reached ground
     * path (near post 2.34 → 1.95 a team against 1) and completes the most crosses (21.8%).
     */
    risk: 3,
    /**
     * The keeper's claim on a lofted delivery above `DUEL_CONFIG.cross.claim` (T447): 0.15. With
     * the far post 8 m out it took validation round 70's 2,400 core matches from 2.85 to 2.84 goals
     * a match, and far-post balls reaching their runner from 21.3 to 17.2% (calibration round 76).
     */
    claim: 0.15,
  },
  /**
   * The bodies in front of goal (T445, →MATCH-35; `shotBlockers`, `resolveShot`). Every outfield
   * opponent within `lane` m of the triangle from the ball to the two posts, ahead of the ball, may
   * block the shot: `block` × his nearness (1 at the shooter, falling linearly to `far` at the
   * goal line, along the line to the goal's middle) × (1 + (위치선정 − 55) ×
   * `SHOT_CONFIG.block.skill`). A block that stays in play falls `rebound.block` m back toward the
   * shooter from the blocker; a save the keeper parries loose falls `rebound.save` m out from him,
   * `rebound.wide` m sideways a metre out toward the shot's side of the goal (one draw each).
   */
  shot: {
    lane: 1.5,
    /**
     * T437: 0.35 → 0.26. The initial value blocked 36% of shots (real football about a quarter)
     * and left 25% on target (MATCH-23 30–37%); at 0.26 23% are blocked and 28% on target
     * (calibration round 74, core 600 matches). Lower still loses corners (a block goes out for
     * one 65% of the time): 0.22 took them to 4.2 a team (MATCH-23 4–6).
     */
    block: 0.26,
    far: 0.4,
    /**
     * A header's block chance against a shot with the foot's (T437, T445's open question): the
     * bodies in a header's path are the marker its aerial duel already priced (`headerPressure`)
     * and the men on the line, so the same `block` stopped 66% of headers. T437 keeps 0.15:
     * set-piece headers blocked 67 → 11%, headed goals 5.6 → 14.3% (MATCH-23 14–20%), set-piece
     * goals 8.7 → 18.0% (20–28%).
     */
    header: 0.15,
    /**
     * Revision 7 (T548, →MATCH-35; `closingBlockers`): as a shot with the foot is struck, every
     * outfield opponent within `radius` m of the shooter who is not one of the bodies in its path
     * closes it down — chasing, beside or in front — and blocks it with `block` × (1 − his distance
     * / `radius`) × the mean of his 태클 and 위치선정 against `skill`, within 0–1, before the path's
     * bodies and the keeper.
     */
    close: { radius: 6, block: 0.35, skill: 60 },
    rebound: {
      block: [4, 9] as readonly [number, number],
      save: [5, 10] as readonly [number, number],
      wide: [0.5, 1.5] as readonly [number, number],
    },
    /**
     * Revision 10 (T596, →MATCH-35 r44; `secondBall`): a block or parry left in play is won clear
     * of the man who met the shot, beyond his body: nobody reaches its first `clear` m from him,
     * `LANE_CONFIG.reach`, the reach within which he would play it himself. Before it an attacker
     * within reach of him met it on his own spot and shot again from on top of him.
     */
    revision10: { clear: 1.2 },
  },
} as const;

const B = BOX_CONFIG;
const CENTRE = PITCH.width / 2;

/** The wing positions on each side of the attack frame, for the far-side winger. */
const WINGERS: Record<BallSide, readonly Position[]> = { [-1]: ['RW', 'RM'], 1: ['LW', 'LM'] };
/** The full-backs and wing-backs on each side of the defending frame, for the far post. */
const FULL_BACKS: Record<BallSide, readonly Position[]> = { [-1]: ['LB', 'LWB'], 1: ['RB', 'RWB'] };

/** The zones for a ball on `ball`'s side of the goal, in the attacking side's frame. */
export function boxZones(ball: BallSide): Record<BoxZone, Point> {
  const Z = B.zones;
  const near = CENTRE + ball * (B.post - Z.nearPost.inside);
  const far = CENTRE - ball * (B.post + Z.farPost.beyond);
  return {
    nearPost: [PITCH.length - Z.nearPost.out, near],
    farPost: [PITCH.length - Z.farPost.out, far],
    spot: [PITCH.length - Z.spot.out, CENTRE],
    edge: [PITCH.length - Z.edge.out, CENTRE],
  };
}

/**
 * Whether a set piece's jobs hold (→MATCH-18, §4.7): a restart being prepared, a box spot held
 * for its second ball, or a defender's set-piece mark or guard. Its defence stays §4.7's, so the
 * open-play scene waits.
 */
function setPieceHeld(s: GridState): boolean {
  for (const roster of s.players)
    for (const gp of roster) {
      const i = gp.intention;
      if (!i || !onPitch(gp)) continue;
      if (i.priority === 'restart') return true;
      if (i.priority !== 'committed' || i.box) continue;
      if (i.kind === 'mark' || (i.kind === 'cover' && i.zone) || i.kind === 'run') return true;
    }
  return false;
}

/**
 * The ball's side of the goal while `side`'s box scene is on, else undefined: the candidate
 * model, `side` on the ball in open play, the ball (its attack frame) in a wide lane from
 * `wideFrom` up or in a cut-back zone (the half-space cells of the goal-area band, MATCH-14).
 */
export function boxSide(s: GridState, side: 0 | 1): BallSide | undefined {
  if (s.setup.model === undefined || s.possession !== side || s.owner?.[0] !== side) return;
  const [x, y] = attackFrame(side, s.ball);
  const lane = laneOf(y);
  const wide = (lane === 0 || lane === 4) && x >= B.wideFrom;
  const cutBack = (lane === 1 || lane === 3) && x >= BAND_EDGES[7];
  if (!wide && !cutBack && !(B.centralFrom > 0 && x >= B.centralFrom)) return;
  if (setPieceHeld(s)) return;
  return y < CENTRE ? -1 : 1;
}

/**
 * Whether a box-scene job of `attacking`'s attack, named for `ball`, still holds: `attacking` keeps
 * the ball in its final third (the scene's area, from `wideFrom` up) and, while the scene is on,
 * the ball is still on that side of the goal. It releases when the ball leaves the area or is
 * cleared (a turnover).
 */
export function boxHeld(s: GridState, attacking: 0 | 1, ball: BallSide): boolean {
  if (s.possession !== attacking) return false;
  if (attackFrame(attacking, s.ball)[0] < B.wideFrom) return false;
  const now = boxSide(s, attacking);
  return now === undefined || now === ball;
}

/** A side's box scene now: the ball's side of the goal, its zones and who attacks each. */
export interface BoxScene {
  /** The attacking side. */
  side: 0 | 1;
  ball: BallSide;
  /** Each zone, in the attacking side's frame. */
  zones: Record<BoxZone, Point>;
  /** Who attacks each zone (roster index): the runner already on it, else the attacker picked now. */
  runners: Partial<Record<BoxZone, number>>;
}

/** Whether his role makes box runs (→PLAYER-5): `SHAPE_CONFIG`'s box-run roles and `BOX_CONFIG.roles`. */
const boxRole = (role: RoleId) =>
  BOX_ROLES.includes(role) ||
  SHAPE_CONFIG.candidate.boxRun.extra.includes(role) ||
  B.roles.includes(role);

/**
 * `side`'s box scene (→MATCH-33), or undefined while it is off (`boxSide`). Each zone gets at most
 * one attacker: one already on its run keeps it, and the free zones go nearest suitable pair
 * first, ties by player ID. The forwards take the near and the far post; a midfielder whose role
 * makes box runs or the far-side winger takes the penalty spot or a post left free; another
 * midfielder takes the edge. Never the carrier, the rest defence (`COORDINATION_CONFIG.rest`), a
 * man `claimed` for another job, one holding anything but a tactical run, or one further than
 * `reach` m from the zone.
 */
export function boxScene(
  s: GridState,
  side: 0 | 1,
  claimed?: ReadonlySet<GridPlayer>,
): BoxScene | undefined {
  const ball = boxSide(s, side);
  if (ball === undefined) return undefined;
  const zones = boxZones(ball);
  const runners: Partial<Record<BoxZone, number>> = {};
  const roster = s.players[side];
  for (const gp of [...roster].sort(byId)) {
    const job = gp.intention?.kind === 'run' ? gp.intention.box : undefined;
    if (!job || job.ball !== ball || !onPitch(gp) || job.zone === 'middle') continue;
    runners[job.zone] ??= gp.idx;
  }
  const taken = new Set(Object.values(runners));
  const pool = roster.filter((gp) => {
    if (!onPitch(gp) || gp.slot <= 0 || taken.has(gp.idx) || claimed?.has(gp)) return false;
    if (s.owner?.[0] === side && s.owner[1] === gp.idx) return false;
    if (COORDINATION_CONFIG.rest.includes(slotOf(s, gp).position)) return false;
    const i = gp.intention;
    return !i || (i.kind === 'run' && i.priority === 'tactical');
  });
  const pairUp = (wanted: readonly BoxZone[], who: (gp: GridPlayer) => boolean) => {
    const pairs: { zone: BoxZone; gp: GridPlayer; d: number }[] = [];
    for (const zone of wanted) {
      if (runners[zone] !== undefined) continue;
      for (const gp of pool) {
        if (taken.has(gp.idx) || !who(gp)) continue;
        const d = gap(attackFrame(side, gp.pos), zones[zone]);
        if (d <= B.reach) pairs.push({ zone, gp, d });
      }
    }
    pairs.sort(
      (a, b) =>
        a.d - b.d || byId(a.gp, b.gp) || BOX_ZONES.indexOf(a.zone) - BOX_ZONES.indexOf(b.zone),
    );
    for (const { zone, gp } of pairs) {
      if (runners[zone] !== undefined || taken.has(gp.idx)) continue;
      runners[zone] = gp.idx;
      taken.add(gp.idx);
    }
  };
  const line = (gp: GridPlayer) => lineOf(slotOf(s, gp).position);
  if (B.rotate) {
    pairUp(
      ['nearPost', 'farPost', 'spot'],
      (gp) =>
        line(gp) === 'FW' ||
        (line(gp) === 'MF' && boxRole(slotOf(s, gp).role)) ||
        WINGERS[ball].includes(slotOf(s, gp).position),
    );
  } else {
    pairUp(['nearPost', 'farPost'], (gp) => line(gp) === 'FW');
    pairUp(
      ['spot', 'nearPost', 'farPost'],
      (gp) =>
        (line(gp) === 'MF' && boxRole(slotOf(s, gp).role)) ||
        WINGERS[ball].includes(slotOf(s, gp).position),
    );
  }
  pairUp(['edge'], (gp) => line(gp) === 'MF');
  return { side, ball, zones, runners };
}

/**
 * Where `side`'s runner of `zone` heads (engine frame): his load point `load` m short of it
 * toward halfway, or, once a cross or cut-back is decided, the zone itself (`attack`).
 */
export function boxRunPoint(
  side: 0 | 1,
  ball: BallSide,
  zone: BoxZone,
  attack: boolean,
): [number, number] {
  const p = boxZones(ball)[zone];
  return toEngine(side, attack ? p : [p[0] - B.load, p[1]]);
}

/** The point `side`'s delivery `aim` is played into (engine frame): its zone itself (T444). */
export const deliveryPoint = (side: 0 | 1, aim: DeliveryAim): [number, number] =>
  toEngine(side, boxZones(aim.ball)[aim.zone]);

/**
 * Who reaches `side`'s delivery `aim` from `from` (engine frame), kicked `kickAt` seconds from now
 * (→MATCH-31, MATCH-33; T444, T446): a ball along the ground on its whole path into its zone, as a
 * pass is; a lofted one on its path to its zone's edge (`delivery.freeRadius` m from its point), the
 * men in the zone left to the aerial duel, and only within `loft.foot` m off the crosser's foot and
 * its last `loft.drop` m (`reachOnPath`'s lofted mode). `cut` is the man who cuts it out: the first
 * who gets there cleanly, for a lofted ball only at the crosser's foot. A lofted ball's `marker` is
 * the man who gets to its drop first when nobody stands in its zone: he meets it in the air there.
 */
export function deliveryReach(
  s: GridState,
  side: 0 | 1,
  from: readonly [number, number],
  aim: DeliveryAim,
  kickAt: number,
): PathReach & { cut?: LaneReach; marker?: GridPlayer } {
  const D = B.delivery;
  const zone = deliveryPoint(side, aim);
  if (!lofted(aim.kind)) {
    const reach = reachOnPath(s, side, from, zone, kickAt);
    return { ...reach, cut: reach.clean };
  }
  const inZone = (gp: GridPlayer) =>
    s.math.hypot(gp.pos[0] - zone[0], gp.pos[1] - zone[1]) <= D.freeRadius;
  const length = s.math.hypot(zone[0] - from[0], zone[1] - from[1]);
  const k = Math.max(0, 1 - D.freeRadius / Math.max(1e-9, length));
  const end: [number, number] = [
    from[0] + (zone[0] - from[0]) * k,
    from[1] + (zone[1] - from[1]) * k,
  ];
  const reach = reachOnPath(s, side, from, end, kickAt, inZone, D.loft);
  const cut = reach.clean && reach.clean.along <= D.loft.foot ? reach.clean : undefined;
  const guarded = s.players[other(side)].some((gp) => onPitch(gp) && inZone(gp));
  const marker = guarded ? undefined : reach.drop?.gp;
  return { ...reach, ...(cut ? { cut } : {}), ...(marker ? { marker } : {}) };
}

/** How a ball of `kind` suits `side`'s runner `idx`: his `lofted` or `low` attributes' 0–1 shares. */
function suits(s: GridState, side: 0 | 1, idx: number, kind: DeliveryKind): number {
  let sum = 0;
  for (const [a, w] of Object.entries(lofted(kind) ? B.delivery.lofted : B.delivery.low))
    sum += w! * (clamp(skill(s, side, idx, a as Attribute), 1, 99) / 99);
  return sum;
}

/**
 * The deliveries `side`'s carrier `idx` may play now (→MATCH-33, T444): one into each zone a
 * teammate attacks in the box scene (`boxScene`'s runners, on the zone's run or picked for it), of
 * each kind `delivery.kinds` names for it, a `square` ball only with the carrier in the goal-area
 * band. None while the scene is off: the ball is not delivered blind. Each weighs `delivery.free`
 * when no opponent stands within `freeRadius` m of the zone, `suit` × how the ball suits the runner
 * (`suits`) and the zone's xT, and carries its path's reach as everyone stands (`deliveryReach`
 * kicked now, T446), which the carrier's choice reads (`chooseDelivery`).
 */
export function deliveries(s: GridState, side: 0 | 1, idx: number): Delivery[] {
  const scene = boxScene(s, side);
  if (!scene) return [];
  const D = B.delivery;
  const from = s.players[side][idx]!.pos;
  const byline = attackFrame(side, from)[0] >= BAND_EDGES[7];
  const opponents = s.players[other(side)].filter(onPitch).map((gp) => attackFrame(side, gp.pos));
  const out: Delivery[] = [];
  for (const zone of BOX_ZONES) {
    const runner = scene.runners[zone];
    if (runner === undefined || runner === idx) continue;
    const at = scene.zones[zone];
    const free = opponents.every((o) => gap(o, at) > D.freeRadius) ? D.free : 0;
    const threat = CELL_BASELINES[cellOf(at)]!.xT;
    for (const kind of D.kinds[zone]) {
      if (kind === 'square' && !byline) continue;
      const score = free + D.suit * suits(s, side, runner, kind) + threat;
      const aim = { zone, kind, ball: scene.ball };
      const path = deliveryReach(s, side, from, aim, 0);
      out.push({ ...aim, runner, score, reach: path.weight, cut: path.cut !== undefined });
    }
  }
  return out;
}

/**
 * How far from its goal `side`'s back line stands against the box scene now (its own frame):
 * `defend.line`'s deeper end with the ball on the byline, the shallower with it `wideFrom` up.
 */
export function boxLineDepth(s: GridState, side: 0 | 1): number {
  const [lo, hi] = B.defend.line;
  const ball = attackFrame(side, s.ball)[0];
  return lo + (hi - lo) * clamp(ball / (PITCH.length - B.wideFrom), 0, 1);
}

/**
 * Where a defender of `side` guarding `guard` against a scene named for `ball` stands now (engine
 * frame, →MATCH-34): the near post, the middle (between the posts' zones) and the far post on the
 * back line's depth (`boxLineDepth`), the penalty spot and the edge on their zones.
 */
export function boxGuardPoint(
  s: GridState,
  side: 0 | 1,
  guard: BoxGuard,
  ball: BallSide,
): [number, number] {
  const att = other(side);
  const zones = boxZones(ball);
  // A zone in the defending side's frame: both axes mirror between the two sides' frames.
  const own = (p: Point): Point => [PITCH.length - p[0], PITCH.width - p[1]];
  const depth = boxLineDepth(s, side);
  if (guard === 'spot' || guard === 'edge') return toEngine(att, zones[guard]);
  const y =
    guard === 'middle'
      ? (own(zones.nearPost)[1] + own(zones.farPost)[1]) / 2
      : own(zones[guard])[1];
  return toEngine(side, [depth, y]);
}

/** The opponent of `side` attacking `zone` of a scene named for `ball`, if one is on that run. */
export function zoneRunner(
  s: GridState,
  side: 0 | 1,
  zone: BoxGuard,
  ball: BallSide,
): GridPlayer | undefined {
  if (zone === 'middle') return undefined;
  for (const gp of s.players[other(side)]) {
    const job = gp.intention?.kind === 'run' ? gp.intention.box : undefined;
    if (job && job.zone === zone && job.ball === ball && onPitch(gp)) return gp;
  }
  return undefined;
}

/**
 * Where `gp`, guarding `guard` of a scene named for `ball`, stands now (engine frame, →MATCH-34):
 * goal-side of the runner who attacks his zone, between him and it (`boxMarkPoint`); with nobody
 * attacking it, on his guard point (`boxGuardPoint`): the zone is held by position.
 */
export function boxGuardTarget(
  s: GridState,
  gp: GridPlayer,
  guard: BoxGuard,
  ball: BallSide,
): [number, number] {
  const runner = zoneRunner(s, gp.side, guard, ball);
  return (runner && boxMarkPoint(gp.side, runner)) ?? boxGuardPoint(s, gp.side, guard, ball);
}

/**
 * The defending side's place in the scene (`side`'s frame, →MATCH-34): a back-line player drops to
 * the line's depth and narrows by `defend.narrow` toward the centre line.
 */
export const boxBackLine = (s: GridState, side: 0 | 1, y: number): Point => [
  boxLineDepth(s, side),
  CENTRE + (y - CENTRE) * B.defend.narrow,
];

/**
 * The ball's side of the goal while `side` defends against a box scene, else undefined: the
 * opponent's scene is on, or one of `side`'s guards still holds its job (the scene not released).
 */
export function defendingBox(s: GridState, side: 0 | 1): BallSide | undefined {
  const on = boxSide(s, other(side));
  if (on !== undefined) return on;
  for (const gp of s.players[side]) {
    const job = gp.intention?.kind === 'cover' ? gp.intention.box : undefined;
    if (job && onPitch(gp)) return job.ball;
  }
  return undefined;
}

/**
 * Who of the defending `side` takes which guard against `scene` (→MATCH-34): the ball-side
 * centre-back the near post, the most central other centre-back the middle, the far full-back or
 * wing-back the far post, and the nearest holding or central midfielder the edge, or the spot
 * when the attack fills the spot and not the edge. Only men `free` for a job, and only guards no
 * teammate already holds; ties by player ID.
 */
export function boxGuards(
  s: GridState,
  side: 0 | 1,
  scene: BoxScene,
  free: (gp: GridPlayer) => boolean,
): { gp: GridPlayer; guard: BoxGuard }[] {
  const roster = s.players[side].filter((gp) => onPitch(gp) && gp.slot > 0);
  const held = new Set<BoxGuard>();
  for (const gp of roster) {
    const job = gp.intention?.kind === 'cover' ? gp.intention.box : undefined;
    if (job && job.ball === scene.ball) held.add(job.zone);
  }
  const out: { gp: GridPlayer; guard: BoxGuard }[] = [];
  const used = new Set<GridPlayer>();
  const pos = (gp: GridPlayer) => slotOf(s, gp).position;
  // The ball's side in the defending frame is the other one; a slot's spot y is in that frame.
  const ballSide = -scene.ball;
  const spotY = (gp: GridPlayer) => SPOTS[s.setup.tactics[side]][gp.slot]![1];
  const toBall = (gp: GridPlayer) => ballSide * (spotY(gp) - CENTRE);
  const give = (gp: GridPlayer | undefined, guard: BoxGuard) => {
    if (!gp || held.has(guard)) return;
    out.push({ gp, guard });
    used.add(gp);
  };
  const cbs = roster
    .filter((gp) => pos(gp) === 'CB' && free(gp))
    .sort((a, b) => toBall(b) - toBall(a) || byId(a, b));
  give(cbs[0], 'nearPost');
  const central = cbs
    .filter((gp) => !used.has(gp))
    .sort(
      (a, b) =>
        Math.abs(spotY(a) - CENTRE) - Math.abs(spotY(b) - CENTRE) ||
        toBall(b) - toBall(a) ||
        byId(a, b),
    )[0];
  give(central, 'middle');
  give(
    roster
      .filter((gp) => FULL_BACKS[scene.ball].includes(pos(gp)) && free(gp) && !used.has(gp))
      .sort(byId)[0],
    'farPost',
  );
  if (!held.has('edge') && !held.has('spot')) {
    const zone: BoxGuard =
      scene.runners.edge === undefined && scene.runners.spot !== undefined ? 'spot' : 'edge';
    const at = boxGuardPoint(s, side, zone, scene.ball);
    const mid = roster
      .filter((gp) => (pos(gp) === 'DM' || pos(gp) === 'CM') && free(gp) && !used.has(gp))
      .map((gp) => ({ gp, d: gap(gp.pos, at) }))
      .sort((a, b) => a.d - b.d || byId(a.gp, b.gp))[0];
    give(mid?.gp, zone);
  }
  return out;
}

/**
 * Where a marker of `side` stands against a runner on a box-scene run (engine frame, →MATCH-34):
 * goal-side of him, between him and the zone he attacks, `SHAPE_CONFIG.markGoalSide` m from him;
 * straight goal-side once he is that close to his zone. Undefined for any other runner.
 */
export function boxMarkPoint(side: 0 | 1, runner: GridPlayer): [number, number] | undefined {
  const job = runner.intention?.kind === 'run' ? runner.intention.box : undefined;
  if (!job || job.zone === 'middle') return undefined;
  const zone = toEngine(other(side), boxZones(job.ball)[job.zone]);
  const dx = zone[0] - runner.pos[0],
    dy = zone[1] - runner.pos[1];
  const d = gap(zone, runner.pos);
  const step = SHAPE_CONFIG.markGoalSide;
  if (d > step) return [runner.pos[0] + (dx / d) * step, runner.pos[1] + (dy / d) * step];
  const o = attackFrame(side, runner.pos);
  return toEngine(side, [Math.max(0, o[0] - step), o[1]]);
}
