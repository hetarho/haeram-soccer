/** Scoring calibration: fixed squads over season-shaped fixtures; no settlement or goal reassignment. */
import { execFileSync, fork } from 'node:child_process';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { ATTRIBUTES } from '../packages/contracts/src/player';
import { MATCH_MODEL_REVISION } from '../packages/contracts/src/match-model';
import type { Fixture, MatchRecord, Player, Tactic, World } from '../packages/contracts/src/types';
import { createWorld, simulateSeason } from '../packages/engine/src/founding';
import { decode } from '../apps/web/src/adapters/persistence';
import { activePlayers, clubOf, overall } from '../packages/engine/src/player-state';
import type { ShotDiagnostic } from '../packages/engine/src/grid/record';
import { npcSquad } from '../packages/engine/src/world';
import { lineOf, FORMATIONS } from '../packages/engine/src/player';
import { playGrid } from '../packages/engine/src/grid/engine';
import { buildGridSetup } from '../packages/engine/src/grid/setup';
import { validateFullMatchRecord } from '../packages/engine/src/match-model';
import { DECISION_CONFIG } from '../packages/engine/src/grid/decide';
import { SHAPE_CONFIG } from '../packages/engine/src/grid/shape';
import { BOX_CONFIG } from '../packages/engine/src/grid/box';
import { COORDINATION_CONFIG } from '../packages/engine/src/grid/coordination';
import { ROLE_SHIFT } from '../packages/engine/src/grid/spots';
import { PITCH } from '../packages/engine/src/grid/pitch';
import { random } from '../packages/engine/src/primitives';
import { measurementIdentity } from './lib/measurement-identity';
import { applyBehaviour, type BehaviourPatch } from './t328-counter-roles-variants';

const args = process.argv.slice(2);
const arg = (name: string, fallback: string) => {
  const i = args.indexOf(`--${name}`);
  return i < 0 ? fallback : args[i + 1]!;
};
const TACTICS: Tactic[] = ['possession', 'press', 'counter', 'balanced'];
const partition = arg('partition', 'calibration');
const seeds = Number(arg('seeds', '2'));
const games = Number(arg('games', '12'));
const career = args.includes('--career');
const patches: Record<string, BehaviourPatch> = {
  baseline: {},
  activeMark: {
    decide: { candidate: { revision4: { gain: 0.08, shotScale: 0.28 }, revision9: { clear: { alone: 0 } }, through: { score: 0.6 } } },
    shape: { candidate: { boxRun: { odds: 3, from: 4, duration: 2.4, hold: true }, revision10: { goalSide: { near: 50, zone: 35, pick: 24, blend: 1, room: 0 } } } },
    coordination: { mark: { stationary: true } },
    box: { reach: 50, zones: { nearPost: { out: 7 }, farPost: { out: 10 } } },
  },
  activeOpen: {
    decide: { candidate: { revision4: { gain: 0.08, shotScale: 0.12, shotQuality: { ref: 0.12, power: 0.35 } }, through: { score: 0.6 } } },
    shape: { candidate: { boxRun: { odds: 3, from: 4, duration: 2.4, hold: true }, revision10: { goalSide: { near: 50, zone: 35, pick: 24, blend: 1, room: 0 } } } },
    coordination: { mark: { stationary: true } },
    box: { reach: 50, zones: { nearPost: { out: 7 }, farPost: { out: 10 } } },
  },
  followMark: {
    decide: { candidate: { revision4: { gain: 0.08, shotScale: 0.28 }, revision9: { clear: { alone: 0 } }, through: { score: 0.6 } } },
    shape: { candidate: { boxRun: { odds: 3, from: 4, duration: 2.4, hold: true }, revision9: { markRadius: 18 }, revision10: { goalSide: { near: 50, zone: 35, pick: 24, blend: 1, room: 0, follow: true } } } },
    box: { reach: 50, zones: { nearPost: { out: 7 }, farPost: { out: 10 } } },
  },
  followOpen: {
    decide: { candidate: { revision4: { gain: 0.08, shotScale: 0.12, shotQuality: { ref: 0.12, power: 0.35 } }, through: { score: 0.6 } } },
    shape: { candidate: { boxRun: { odds: 3, from: 4, duration: 2.4, hold: true }, revision9: { markRadius: 18 }, revision10: { goalSide: { near: 50, zone: 35, pick: 24, blend: 1, room: 0, follow: true } } } },
    box: { reach: 50, zones: { nearPost: { out: 7 }, farPost: { out: 10 } } },
  },
  clearView: {
    decide: {
      candidate: {
        revision4: { gain: 0.08, shotScale: 0.28 },
        revision9: { clear: { alone: 0 } },
        through: { score: 0.6 },
      },
    },
    shape: {
      candidate: {
        boxRun: { odds: 3, from: 4, duration: 2.4, hold: true },
        revision10: { goalSide: { near: 55, zone: 35, pick: 18, blend: 1, room: 0 } },
      },
    },
    box: { reach: 50, zones: { nearPost: { out: 7 }, farPost: { out: 10 } } },
  },
  clearCentral: {
    decide: {
      candidate: {
        revision4: { gain: 0.06, shotScale: 0.28, shotLine: { MF: 1, DF: 0.7 } },
        revision9: { clear: { alone: 0 } },
        through: { score: 0.5 },
        past: { prior: 0.35 },
      },
    },
    shape: { candidate: { boxRun: { odds: 3, from: 4, duration: 2.4, hold: true } } },
    box: {
      centralFrom: 75,
      rotate: true,
      reach: 50,
      zones: { nearPost: { out: 7 }, farPost: { out: 10 } },
    },
  },
  clearSpread: {
    decide: {
      candidate: {
        revision4: { gain: 0.06, shotScale: 0.28, shotLine: { MF: 1, DF: 0.7 } },
        revision9: { clear: { alone: 0 } },
        through: { score: 0.5 },
        past: { prior: 0.35 },
      },
    },
    shape: {
      candidate: {
        boxRun: { odds: 3, from: 4, duration: 2.4, hold: true },
        revision10: { goalSide: { near: 55, zone: 35, pick: 18, blend: 1, room: 0 } },
      },
    },
    box: {
      centralFrom: 75,
      rotate: true,
      reach: 50,
      zones: { nearPost: { out: 9 }, farPost: { out: 13 }, spot: { out: 11 } },
    },
  },
  central75: {
    decide: {
      candidate: {
        revision4: { gain: 0.06, shotScale: 0.16, shotQuality: { ref: 0.12, power: 0.35 } },
        through: { score: 0.5 },
        past: { prior: 0.35 },
      },
    },
    shape: { candidate: { boxRun: { odds: 3, from: 4, duration: 2.4, hold: true } } },
    box: {
      centralFrom: 75,
      rotate: true,
      reach: 50,
      zones: { nearPost: { out: 7 }, farPost: { out: 10 } },
    },
  },
  central85: {
    decide: {
      candidate: {
        revision4: { gain: 0.06, shotScale: 0.16, shotQuality: { ref: 0.12, power: 0.35 } },
        through: { score: 0.5 },
        past: { prior: 0.35 },
      },
    },
    shape: { candidate: { boxRun: { odds: 3, from: 4, duration: 2.4, hold: true } } },
    box: { centralFrom: 85, reach: 50, zones: { nearPost: { out: 7 }, farPost: { out: 10 } } },
  },
  holdBox: {
    decide: {
      candidate: {
        revision4: { gain: 0.06, shotScale: 0.16, shotQuality: { ref: 0.12, power: 0.35 } },
        through: { score: 0.5 },
        past: { prior: 0.35 },
      },
    },
    shape: { candidate: { boxRun: { odds: 3, from: 4, duration: 2.4, hold: true } } },
    box: { reach: 50, zones: { nearPost: { out: 7 }, farPost: { out: 10 } } },
  },
  longRuns: {
    decide: {
      candidate: {
        revision4: { gain: 0.06, shotScale: 0.16, shotQuality: { ref: 0.12, power: 0.35 } },
        through: { score: 0.5 },
        past: { prior: 0.35 },
      },
    },
    shape: { candidate: { boxRun: { odds: 3, from: 4, duration: 2.4 } } },
    box: { reach: 50, zones: { nearPost: { out: 7 }, farPost: { out: 10 } } },
  },
  onside: {
    decide: {
      candidate: {
        revision4: { gain: 0.06, shotScale: 0.16, shotQuality: { ref: 0.12, power: 0.35 } },
        through: { score: 0.5 },
        past: { prior: 0.15 },
      },
    },
    shape: { candidate: { boxRun: { odds: 2, from: 4 } } },
    box: { reach: 50, zones: { nearPost: { out: 7 }, farPost: { out: 10 } } },
  },
  room: {
    decide: {
      candidate: {
        revision4: { gain: 0.06, shotScale: 0.16, shotQuality: { ref: 0.12, power: 0.35 } },
        through: { score: 0.5 },
        past: { prior: 0.35 },
      },
    },
    shape: {
      candidate: { boxRun: { odds: 3, from: 4 }, revision8: { room: 6, spread: { radius: 10 } } },
    },
    box: { reach: 50, zones: { nearPost: { out: 7 }, farPost: { out: 10 } } },
  },
  choice: {
    decide: {
      candidate: {
        revision4: { gain: 0.03, shotScale: 0.12, shotQuality: { ref: 0.12, power: 0.35 } },
        through: { score: 0.3 },
        revision6: { free: { score: 0.4 } },
        revision9: { tight: { mark: 4, score: 1.5 } },
      },
    },
    shape: { candidate: { boxRun: { odds: 3, from: 4 } } },
    box: { reach: 50, zones: { nearPost: { out: 7 }, farPost: { out: 10 } } },
  },
  earlyMark: {
    decide: {
      candidate: {
        revision4: { gain: 0.08, shotScale: 0.12, shotQuality: { ref: 0.12, power: 0.35 } },
        through: { score: 0.6 },
      },
    },
    shape: {
      candidate: {
        boxRun: { odds: 2, from: 4 },
        revision9: { markRadius: 24 },
        revision10: { goalSide: { near: 60, zone: 45, pick: 30, blend: 1, room: 0 } },
      },
    },
    box: { reach: 50, zones: { nearPost: { out: 7 }, farPost: { out: 10 } } },
  },
  earlySupport: {
    decide: {
      candidate: {
        revision4: { gain: 0.08, shotScale: 0.1, shotQuality: { ref: 0.12, power: 0.35 } },
        through: { score: 0.6 },
      },
    },
    shape: {
      candidate: {
        boxRun: { odds: 4, from: 4, extra: ['invertedWinger', 'boxToBox', 'mezzala'] },
        revision9: { markRadius: 24 },
        revision10: { goalSide: { near: 60, zone: 45, pick: 30, blend: 1, room: 0 } },
      },
    },
    box: { reach: 55, zones: { nearPost: { out: 9 }, farPost: { out: 11 }, spot: { out: 11 } } },
  },
  volume: { decide: { candidate: { revision4: { shotScale: 0.18 } } } },
  passing: {
    decide: { candidate: { revision4: { gain: 0.08 }, through: { score: 0.6 } } },
  },
  support: {
    decide: { candidate: { revision4: { gain: 0.12 }, through: { score: 1 } } },
    shape: { candidate: { boxRun: { odds: 2, extra: ['invertedWinger', 'boxToBox'] } } },
  },
  spatial: {
    decide: { candidate: { revision4: { gain: 0.08, shotScale: 0.18 }, through: { score: 0.6 } } },
    shape: { candidate: { boxRun: { odds: 2, from: 4 } } },
    box: { reach: 42, zones: { nearPost: { out: 6 }, farPost: { out: 10 } } },
  },
  spatial2: {
    decide: {
      candidate: {
        revision4: { gain: 0.08, shotScale: 0.12, shotQuality: { ref: 0.12, power: 0.35 } },
        through: { score: 0.6 },
      },
    },
    shape: { candidate: { boxRun: { odds: 2, from: 4 } } },
    box: { reach: 50, zones: { nearPost: { out: 7 }, farPost: { out: 10 } } },
  },
  shotmix: {
    decide: {
      candidate: {
        revision4: { gain: 0.08, shotScale: 0.12, shotQuality: { ref: 0.12, power: 0.35 } },
        through: { score: 0.6 },
      },
    },
    shape: { candidate: { boxRun: { odds: 2, from: 4 } } },
  },
  shotmixMark: {
    decide: {
      candidate: {
        revision4: { gain: 0.08, shotScale: 0.12, shotQuality: { ref: 0.12, power: 0.35 } },
        through: { score: 0.6 },
      },
    },
    shape: {
      candidate: {
        boxRun: { odds: 2, from: 4 },
        revision10: { goalSide: { near: 55, zone: 35, pick: 18, blend: 1, room: 0 } },
      },
    },
  },
  marking: {
    decide: { candidate: { revision4: { gain: 0.08, shotScale: 0.18 }, through: { score: 0.6 } } },
    shape: {
      candidate: { revision10: { goalSide: { near: 55, zone: 35, pick: 18, blend: 1, room: 0 } } },
    },
  },
  circulation: {
    decide: {
      candidate: { revision4: { gain: 0.06, shotScale: 0.18 }, through: { score: 0.5 } },
      pass: { tau: { scale: 1.25, range: [0.7, 2.5] } },
    },
    shape: { run: { boxX: 90 }, candidate: { boxRun: { odds: 3, from: 4 } } },
  },
  combined: {
    decide: {
      candidate: { revision4: { gain: 0.08, shotScale: 0.18 }, through: { score: 0.6 } },
    },
    shape: { candidate: { boxRun: { odds: 2, extra: ['invertedWinger', 'boxToBox'] } } },
  },
};
patches.arrivals = structuredClone(patches.spatial2!);
patches.arrivalsMark = structuredClone(patches.earlySupport!);
const roleShifts = structuredClone(ROLE_SHIFT);
const arrivalShifts: typeof ROLE_SHIFT = {
  boxToBox: [14.7, 0],
  mezzala: [16.8, -4.08],
  attackingMidfielder: [10.5, 0],
  shadowStriker: [12.6, 0],
  invertedWinger: [4.2, 17],
  wideMidfielder: [6.3, 4.08],
};
const selected = arg('variants', Object.keys(patches).join(',')).split(',');
for (const name of selected) if (!patches[name]) throw new Error(`Unknown variant ${name}`);
const baseline = JSON.parse(
  JSON.stringify({
    decide: DECISION_CONFIG,
    shape: SHAPE_CONFIG,
    box: BOX_CONFIG,
    coordination: COORDINATION_CONFIG,
  }),
) as BehaviourPatch;
interface Job {
  variant: string;
  seed: number;
  tactic: Tactic;
  star: boolean;
}
interface Result extends Job {
  careerInfo?: { year: number; tier: number; rank?: number; endTactic: Tactic; star?: string };
  games: number;
  goals: number;
  conceded: number;
  shots: number;
  opponentShots: number;
  hatTricks: number;
  maximum: number;
  invalid: number;
  topGoals: number;
  topShare: number;
  shotContext: Record<
    string,
    {
      shots: number;
      goals: number;
      xg: number;
      clear: number;
      clearGoals: number;
      setPieceGoals: number;
      penaltyGoals: number;
      distance: number;
    }
  >;
  players: { id: string; position: string; goals: number; shots: number; minutes: number }[];
}
const worlds = new Map<number, World>();
function world(seed: number) {
  let w = worlds.get(seed);
  if (!w) {
    w = createWorld({
      country: 'ENG',
      name: 'Scoring reference',
      color: '#224466',
      seed: `scoring-${partition}-${seed}`,
      level: 'normal',
    });
    w.year = 2024;
    worlds.set(seed, w);
  }
  return w;
}
function roster(w: World, club: World['clubs'][number], tactic: Tactic, strength: number) {
  return npcSquad(w.seed, w.year, { ...club, strength }, tactic).map((p) => ({ ...p, fatigue: 0 }));
}
function starPlayer(p: Player) {
  // The owner's retired OVR-85 profile, with six outfield points to represent its OVR-91 peak.
  const values = [
    96.7, 75.76, 61.75, 74.13, 77.17, 66.66, 92.42, 81.58, 91.44, 66.35, 92.02, 13.05, 7.02, 13.81,
    69.27, 93.39,
  ];
  const copy = structuredClone(p);
  ATTRIBUTES.forEach((key, i) => (copy.attrs[key] = values[i]!));
  copy.position = 'ST';
  copy.positions = { ST: 3 };
  copy.traits = ['speedster', 'targetman'];
  return copy;
}
async function run(job: Job): Promise<Result> {
  applyBehaviour(baseline);
  Object.assign(ROLE_SHIFT, roleShifts);
  delete ROLE_SHIFT.wideMidfielder;
  const w = career
    ? (await decode(readFileSync(arg('save', '/tmp/haeram-2036.haeram-save.json'), 'utf8'))).world
    : world(job.seed);
  let careerInfo: Result['careerInfo'];
  let careerMatches: MatchRecord[] | undefined;
  if (career) {
    w.seed += ':scoring-career:' + partition + ':' + job.seed;
    simulateSeason(w); // Shared baseline closes only the original partial season.
    w.tactic = job.tactic;
    w.manager.philosophy = job.tactic;
    const p = activePlayers(w)
      .filter((p) => p.position === 'ST')
      .sort((a, b) => overall(b) - overall(a))[0];
    if (job.star && p) {
      Object.assign(p, starPlayer(p), { born: w.year - 26, potential: 99 });
      delete p.retiring;
      if (w.people?.[p.id]) w.people[p.id]!.born = p.born;
    }
    careerInfo = {
      year: w.year,
      tier: clubOf(w).tier,
      endTactic: w.tactic,
      ...(job.star && p ? { star: p.id } : {}),
    };
  }
  applyBehaviour(patches[job.variant]!);
  if (job.variant.startsWith('arrivals')) Object.assign(ROLE_SHIFT, arrivalShifts);
  if (career) {
    simulateSeason(w);
    careerInfo!.rank = w.history.at(-1)?.rank;
    careerInfo!.endTactic = w.tactic;
    careerMatches = w.ownMatches.filter((m) => m.year === careerInfo!.year && m.kind === 'league');
  }
  const clubs = w.clubs.filter((c) => c.country === 'ENG' && c.tier === 0 && !c.representative);
  const own = career ? clubOf(w) : clubs[job.seed % clubs.length]!,
    other = clubs[(job.seed + 7) % clubs.length]!;
  const ownRoster = career ? w.players : roster(w, own, job.tactic, job.star ? 75 : 80);
  if (job.star && !career) {
    const index = FORMATIONS[job.tactic].slots.findIndex((s) => s.position === 'ST');
    ownRoster[index] = starPlayer(ownRoster[index]!);
  }
  const players = new Map<string, Result['players'][number]>();
  const shotContext: Result['shotContext'] = {};
  let goals = 0,
    conceded = 0,
    shots = 0,
    opponentShots = 0,
    hatTricks = 0,
    maximum = 0,
    invalid = 0;
  const count = careerMatches?.length ?? games;
  for (let i = 0; i < count; i++) {
    const side = careerMatches
      ? careerMatches[i]!.home === w.playerClub
        ? 0
        : 1
      : ((Math.floor(i / TACTICS.length) % 2) as 0 | 1);
    let played: { record: MatchRecord; shots: ShotDiagnostic[] };
    if (careerMatches) played = { record: careerMatches[i]!, shots: [] };
    else {
      const opponentTactic = TACTICS[i % TACTICS.length]!;
      const opponentRoster = roster(w, other, opponentTactic, 80);
      const rosters: [Player[], Player[]] =
        side === 0 ? [ownRoster, opponentRoster] : [opponentRoster, ownRoster];
      const tactics: [Tactic, Tactic] =
        side === 0 ? [job.tactic, opponentTactic] : [opponentTactic, job.tactic];
      const f: Fixture = {
        id: `scoring:${partition}:${job.seed}:${job.tactic}:${job.star}:${i}`,
        year: w.year,
        round: i + 1,
        kind: 'league',
        groupKey: 'ENG:0:0',
        country: 'ENG',
        home: side === 0 ? own.id : other.id,
        away: side === 0 ? other.id : own.id,
      };
      const setup = buildGridSetup(w, f, {
        observe: false,
        recordPlayers: true,
        model: MATCH_MODEL_REVISION,
        lab: { rosters, tactics },
      });
      const result = playGrid(setup);
      played = { record: result.record, shots: result.diagnostics.shots };
    }
    const m = played.record;
    for (const shot of played.shots.filter((shot) => shot.side === side)) {
      const context = (shotContext[shot.line] ??= {
        shots: 0,
        goals: 0,
        xg: 0,
        clear: 0,
        clearGoals: 0,
        setPieceGoals: 0,
        penaltyGoals: 0,
        distance: 0,
      });
      context.shots++;
      context.goals += Number(shot.goal);
      context.xg += shot.xg;
      context.clear += Number(!!shot.clear);
      context.clearGoals += Number(!!shot.clear && shot.goal);
      context.setPieceGoals += Number(shot.setPiece && shot.goal);
      context.penaltyGoals += Number(shot.penalty && shot.goal);
      context.distance += Math.hypot(PITCH.length - shot.x, PITCH.width / 2 - shot.y);
    }
    const lines = side === 0 ? m.players.slice(0, m.lineCounts![0]) : m.players.slice(m.lineCounts![0]);
    // Career storage retains only our player lines; the engine validates the full result before settlement.
    const issues = careerMatches
      ? Array.from({ length: 10 }, (_, index) => {
          const sum = lines.reduce((sum, p) => sum + p.metrics[index]!, 0);
          return sum === m.metrics[side][index] ? [] : ['retained own metric ' + index + ': ' + sum + ' vs ' + m.metrics[side][index]];
        }).flat()
      : validateFullMatchRecord(m);
    if (lines.reduce((sum, p) => sum + p.metrics[0]!, 0) !== (side === 0 ? m.score.home : m.score.away)) issues.push('retained scorer totals differ from score');
    invalid += issues.length;
    if (issues.length) throw new Error(issues.join('; '));
    goals += side === 0 ? m.score.home : m.score.away;
    conceded += side === 0 ? m.score.away : m.score.home;
    shots += m.metrics[side][4]!;
    opponentShots += m.metrics[1 - side][4]!;
    for (const line of lines) {
      const source = ownRoster.find((p) => p.id === line.id)!;
      const p = players.get(line.id) ?? {
        id: line.id,
        position: source.position,
        goals: 0,
        shots: 0,
        minutes: 0,
      };
      p.goals += line.metrics[0]!;
      p.shots += line.metrics[4]!;
      p.minutes += line.metrics[10]!;
      players.set(line.id, p);
      maximum = Math.max(maximum, line.metrics[0]!);
      if (line.metrics[0]! >= 3) hatTricks++;
    }
  }
  const list = [...players.values()].sort((a, b) => b.goals - a.goals);
  const topGoals = list[0]?.goals ?? 0;
  return {
    ...job,
    games: count,
    ...(careerInfo ? { careerInfo } : {}),
    goals,
    conceded,
    shots,
    opponentShots,
    hatTricks,
    maximum,
    invalid,
    topGoals,
    topShare: goals > 0 ? topGoals / goals : 0,
    shotContext,
    players: list,
  };
}
function mean(values: number[]) {
  return values.reduce((a, b) => a + b, 0) / Math.max(1, values.length);
}
/** Resample complete seed clusters, keeping tactics together rather than treating every game as independent. */
function uncertainty(rows: Result[]) {
  const seeds = [...new Set(rows.map((r) => r.seed))];
  const estimates = (group: Result[]) => ({
    goalsPerMatch: mean(group.map((r) => (r.goals + r.conceded) / r.games)),
    shotsPerTeam: mean(group.map((r) => (r.shots + r.opponentShots) / (2 * r.games))),
    topShare: mean(group.map((r) => r.topShare)),
    topGoalsPer38: mean(group.map((r) => (38 * r.topGoals) / r.games)),
    hatTricksPerOwnMatch: mean(group.map((r) => r.hatTricks / r.games)),
  });
  const r = random(`star-balance-ci:${partition}`);
  const samples = Array.from({ length: 2000 }, () =>
    estimates(
      seeds.flatMap(() => {
        const seed = seeds[Math.floor(r() * seeds.length)];
        return rows.filter((row) => row.seed === seed);
      }),
    ),
  );
  const intervals = Object.fromEntries(
    Object.keys(estimates(rows)).map((key) => {
      const values = samples
        .map((sample) => sample[key as keyof typeof sample])
        .sort((a, b) => a - b);
      return [key, [values[49], values[1949]]];
    }),
  );
  return {
    clusters: seeds.length,
    method: '2000 seed-cluster percentile bootstrap, descriptive (not equivalence proof)',
    intervals,
  };
}
function summary(rows: Result[]) {
  const n = rows.reduce((n, r) => n + r.games, 0);
  return {
    teamSeasons: rows.length,
    matches: n,
    goalsByLine: Object.fromEntries(
      ['FW', 'MF', 'DF', 'GK'].map((line) => [
        line,
        rows.reduce(
          (s, r) =>
            s +
            r.players
              .filter((p) => lineOf(p.position as Player['position']) === line)
              .reduce((a, p) => a + p.goals, 0),
          0,
        ) /
          Math.max(
            1,
            rows.reduce((s, r) => s + r.goals, 0),
          ),
      ]),
    ),
    goalsPerMatch: rows.reduce((n, r) => n + r.goals + r.conceded, 0) / n,
    ownGoalsPerMatch: rows.reduce((n, r) => n + r.goals, 0) / n,
    ownShotsPerMatch: rows.reduce((n, r) => n + r.shots, 0) / n,
    opponentShotsPerMatch: rows.reduce((n, r) => n + r.opponentShots, 0) / n,
    topShare: mean(rows.map((r) => r.topShare)),
    topGoalsPer38: mean(rows.map((r) => (38 * r.topGoals) / r.games)),
    largestTopGoalsPer38: Math.max(...rows.map((r) => (38 * r.topGoals) / r.games)),
    hatTricksPerOwnMatch: rows.reduce((n, r) => n + r.hatTricks, 0) / n,
    largestSinglePlayerGoals: Math.max(...rows.map((r) => r.maximum)),
    invalid: rows.reduce((n, r) => n + r.invalid, 0),
    uncertainty95: uncertainty(rows),
  };
}
if (args.includes('--child')) {
  process.on('message', async (job: Job | false) => {
    if (!job) {
      process.disconnect!();
      return;
    }
    try {
      process.send!({ result: await run(job) });
    } catch (error) {
      process.send!({ error: String(error) });
    }
  });
} else {
  const identity = measurementIdentity('scripts/star-balance.ts');
  const jobs: Job[] = selected.flatMap((variant) =>
    Array.from({ length: seeds }, (_, seed) =>
      TACTICS.flatMap((tactic) => [false, true].map((star) => ({ variant, seed, tactic, star }))),
    ).flat(),
  );
  const count = jobs.length,
    rows: Result[] = [],
    started = Date.now();
  await Promise.all(
    Array.from(
      { length: Math.min(Number(arg('jobs', '4')), count) },
      () =>
        new Promise<void>((resolve, reject) => {
          const child = fork(fileURLToPath(import.meta.url), [...args, '--child'], {
            stdio: ['ignore', 'inherit', 'inherit', 'ipc'],
          });
          const next = () => {
            const job = jobs.shift();
            child.send(job ?? false);
          };
          child.on('message', (message: { result?: Result; error?: string }) => {
            if (message.error) {
              reject(new Error(message.error));
              child.disconnect();
              return;
            }
            rows.push(message.result!);
            if (rows.length % 8 === 0)
              console.log(
                `${rows.length}/${count} cases, ${((Date.now() - started) / 1000).toFixed(0)}s`,
              );
            next();
          });
          child.on('exit', (code) => (code ? reject(new Error(`worker exit ${code}`)) : resolve()));
          child.on('error', reject);
          next();
        }),
    ),
  );
  const summaries = Object.fromEntries(
    selected.map((variant) => {
      const group = rows.filter((r) => r.variant === variant);
      return [
        variant,
        {
          normal: summary(group.filter((r) => !r.star)),
          star: summary(group.filter((r) => r.star)),
          byTactic: Object.fromEntries(
            TACTICS.map((tactic) => [
              tactic,
              summary(group.filter((r) => r.tactic === tactic && !r.star)),
            ]),
          ),
        },
      ];
    }),
  );
  const out = arg('out', 'artifacts/benchmarks/star-balance-261103/pilot.json');
  mkdirSync(dirname(out), { recursive: true });
  writeFileSync(
    out,
    JSON.stringify(
      {
        method: career
          ? 'Actual owner-career league season after the shared partial close, full calendar, injuries, fatigue, automatic selection and contracts; synthetic peak-striker arm changes a copied player only. Shot diagnostics are unavailable in persisted matches.'
          : 'v2: fixed fresh squads, each opponent tactic played at both venues, no season settlement; 38-scaled pilot leaders are context only',
        partition,
        seeds,
        games,
        model: MATCH_MODEL_REVISION,
        provenance: {
          commit: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
          node: process.version,
          command: ['pnpm exec tsx scripts/star-balance.ts', ...args].join(' '),
          identity,
          baseline,
          baselineRoleShifts: roleShifts,
        },
        patches: Object.fromEntries(selected.map((v) => [v, patches[v]])),
        roleShifts: Object.fromEntries(
          selected.map((v) => [v, v.startsWith('arrivals') ? arrivalShifts : {}]),
        ),
        seconds: (Date.now() - started) / 1000,
        summaries,
        rows: rows.sort(
          (a, b) =>
            a.variant.localeCompare(b.variant) ||
            a.seed - b.seed ||
            a.tactic.localeCompare(b.tactic) ||
            Number(a.star) - Number(b.star),
        ),
      },
      null,
      2,
    ) + '\n',
  );
  console.log(JSON.stringify({ out, summaries }, null, 2));
}
