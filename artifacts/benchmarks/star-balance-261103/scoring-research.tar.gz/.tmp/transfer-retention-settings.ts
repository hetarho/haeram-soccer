import { readFileSync, writeFileSync } from 'node:fs';
import { decode } from '../apps/web/src/adapters/persistence';
const { world: w } = await decode(readFileSync('/tmp/haeram-2036.haeram-save.json', 'utf8'));
const events = w.events.filter(e => /settings|responsibility|build/.test(e.kind));
const result = { currentYear: w.year, settings: w.settings, build: w.build, direction: w.direction, earliestEvent: w.events[0]?.year, eventCount: w.events.length, settingsEvents: events.map(e => ({year: e.year, kind: e.kind, title: e.title, detail: e.detail})) };
writeFileSync('.tmp/transfer-retention-settings.json', JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
