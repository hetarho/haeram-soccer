import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { decode } from '../apps/web/src/adapters/persistence';
import { ATTRIBUTES } from '../packages/contracts/src/player';
import { saleAllowed, suitorFor, untouchableVerdict } from '../packages/engine/src/transfers';
import { random } from '../packages/engine/src/primitives';
import { overall } from '../packages/engine/src/player-state';

const source = '/tmp/haeram-2036.haeram-save.json';
const raw = readFileSync(source, 'utf8');
const { world: w } = await decode(raw);
const original = w.players.find((p) => p.born === 1973 && p.career[0] === 1211)!;
const open = [];
const protectedOffers = [];
for (const market of ['standard', 'selling', 'showcase', 'hardball', 'hold'] as const) {
  w.build = { ...w.build, market: market === 'standard' ? undefined : market };
  for (const age of [22, 26, 30, 34])
    for (const covered of [false, true])
      open.push({ market, age, starter: true, covered, allowed: saleAllowed(w, true, age, covered) });
  for (const essential of [false, true])
    for (const offered of [90, 130, 160, 175, 200, 225, 300])
      protectedOffers.push({ market, essential, offered, ...untouchableVerdict(w, offered, essential) });
}
const buyers = [];
for (const ability of [75, 80, 81, 85, 90, 91, 95, 99]) {
  const p = structuredClone(original);
  for (const key of ATTRIBUTES) p.attrs[key] = ability;
  const actual = overall(p);
  const seen = new Map<string, number>();
  let absent = 0;
  for (let i = 0; i < 2000; i++) {
    const c = suitorFor(w, p, random('retention-buyer:' + ability + ':' + i));
    if (!c) absent++;
    else seen.set(c.id, (seen.get(c.id) ?? 0) + 1);
  }
  buyers.push({ ability: actual, absent, sampledUniqueBuyers: seen.size, top: [...seen].sort((a, b) => b[1] - a[1]).slice(0, 5).map(([id, count]) => ({ id, count, strength: w.clubs.find((c) => c.id === id)!.strength })) });
}
const events = w.events.filter((e) => e.title.includes(original.name) || e.detail.includes(original.name));
const awards = w.history.flatMap((h) => {
  const a = h.ballonDor?.find((a) => a.id === original.id);
  return a ? [{ year: h.year, tier: h.tier, rank: h.rank, goals: a.goals, appearances: a.appearances, honours: a.honours, closingOVR: a.honours.length ? undefined : 70 + (a.points - 4 * a.goals - 3 * a.assists) / 2 }] : [];
});
const report = {
  sourceSHA256: createHash('sha256').update(raw).digest('hex'),
  sourceYear: w.year,
  note: 'Current source rules and controlled policy/buyer samples; buyer availability uses the current 2036 club snapshot and is not a reconstruction of 1990s clubs. Retired player stance is cleared at retirement; no historical stance is inferred from it.',
  sourcePlayer: { id: original.id, name: original.name, ambition: original.personality.ambition, contracts: events.filter((e) => e.kind === 'contract').length, stanceEvents: events.filter((e) => e.kind === 'transfer-list'), requestEvents: events.filter((e) => e.kind === 'transfer-request'), retainedBids: w.bids?.filter((b) => b.playerId === original.id), transferFacts: w.transfers?.facts.filter((f) => f.player === original.id) },
  awards,
  open,
  protectedOffers,
  buyers,
};
writeFileSync('.tmp/transfer-retention-audit.json', JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ sourcePlayer: report.sourcePlayer, awards, buyers, open }, null, 2));
